<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>v</b> 1.0.0
    </div>
    <strong>Copyright &copy; {{ date('Y') - 1 }} - {{ date('Y') }} <a href="http://dot.biz.id/">Dunia Optima Teknologi</a>.</strong> All rights
    reserved.
</footer>
