<?php $__env->startSection('menu-op','menu-open'); ?>

<?php $__env->startSection('op','active'); ?>

<?php $__env->startSection('po','active'); ?>
<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12 mb-2">
          <h1>Tambah Budgeting</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="#">Operasional</a></li>
            <li class="breadcrumb-item"><a href="#">Manage PO</a></li>
            <li class="breadcrumb-item"><a href="#">Budgeting</a></li>
            <li class="breadcrumb-item active">Tambah Budgeting</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">

      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Tambah Budgeting</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
            </div>
          </div>
          <div class="card-body">
            <form action="#" method="POST"><?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="inputStatus">Pilih Jenis Kendaraan</label>
                    <select class="form-control select2bs4" name="jk">
                      <option selected disabled>--Pilih Jenis Kendaraan--</option>
                      <option>CDD</option>
                      <option>CDE</option>
                      <option>Long/Fuso</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="inputStatus">Pilih Nomor polisi</label>
                    <select class="form-control select2bs4" name="nopol">
                      <option selected disabled>--Pilih Nomor Polisi--</option>
                      <option>B 777 LUK</option>
                      <option>D 444 DED</option>
                      <option>F 4 RES</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="inputName">Catatan</label>
                    <input type="text" id="inputName" class="form-control" name="cat">
                </div>

            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    <div class="row">
      <div class="col-12">
        <a href="<?php echo e(route('klien.index')); ?>" class="btn btn-secondary">Batal</a>
        <input type="submit" value="Tambah Budgeting" class="btn btn-success float-right">
      </div>
    </div>
    </form>
  </section>
  <!-- /.content -->

<?php $__env->startPush('css'); ?>
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  <!-- Select2 -->
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <!-- date-range-picker -->
  <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
  <script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Date range picker
    $('#mulai').datetimepicker({
        format: 'L'
    });

    $('#selesai').datetimepicker({
        format: 'L'
    });
})
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/operasional/i_budgeting.blade.php ENDPATH**/ ?>