<?php $__env->startSection('master-open', 'menu-open'); ?>

<?php $__env->startSection('master-active', 'active'); ?>

<?php $__env->startSection('jabatan-active', 'active'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6 mb-2">
            <h1>Master Jabatan</h1>
          </div>
          <div class="col-sm-6">
            <a href="#" data-toggle="modal" data-target="#modal-tambah" class="btn btn-primary btn-sm float-right"><span class="fa fa-plus">&nbsp;</span>Tambah Jabatan</a>

          </div>
         <div class="col-sm-12">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#">Master Data</a></li>
              <li class="breadcrumb-item active">Master Jabatan</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    
    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-12">
            <div class="card">
              
              
              <div class="card-body">
                <table id="example1" class="table table-striped table-nowrap" cellspacing="0" width="100%">
                  <thead>
                  <tr>
                    <th width="5%">No</th>
                    <th>Nama Jabatan</th>
                    <th width="10%"></th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $no=1; ?>
                  <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-right"><?php echo e($no++); ?></td>
                    <td><?php echo e($r->jabatan_nama); ?></td>
                    <td class="text-right">
                        <div class="btn-group" role="group" aria-label="Button group">
                            <a href="#" data-target="#modal-edit<?php echo e($r->jabatan_id); ?>" data-toggle="modal" class="btn btn-xs btn-link"><span class="fa fa-edit"></span></a>
                            <a href="#" data-target="#modal-hapus<?php echo e($r->jabatan_id); ?>" data-toggle="modal" class="btn btn-xs btn-link"><span class="fa fa-trash"></span></a>
                        </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </section>
    

    <div class="modal fade" id="modal-tambah">
        <div class="modal-dialog">
          <div class="modal-content">
          <form action="<?php echo e(route('jabatan.store')); ?>" method="POST">
            <div class="modal-header bg-primary">
              <h4 class="modal-title">Tambah Jabatan</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama">Nama Jabatan</label>
                    <input type="text" id="nama" class="form-control" name="nama" required>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success">Tambah</button>
            </div>
          </form>
          </div>
          
        </div>
        
      </div>
      

    <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="modal fade" id="modal-edit<?php echo e($r->jabatan_id); ?>">
        <div class="modal-dialog">
          <div class="modal-content">
          <form action="<?php echo e(route('jabatan.update',$r->jabatan_id)); ?>" method="POST">
            <div class="modal-header bg-info">
              <h4 class="modal-title">Edit Jabatan</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="nama">Nama jabatan</label>
                    <input type="text" id="nama" class="form-control" name="nama" value="<?php echo e($r->jabatan_nama); ?>" required>
                </div>

            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success">Update</button>
            </div>
          </form>
          </div>
          
        </div>
        
      </div>
      

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="modal fade" id="modal-hapus<?php echo e($r->jabatan_id); ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <form method="post" action="<?php echo e(route('jabatan.destroy',$r->jabatan_id)); ?>">
            <div class="modal-header bg-danger">
              <h4 class="modal-title">Peringatan</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body text-center text=danger">
              <h3>Apakah anda yakin ingin menghapus Jabatan <u><strong><?php echo e($r->jabatan_nama); ?></strong></u> ?</h3>
            </div>
            <div class="modal-footer justify-content-between">
              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
              <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-danger" onclick="confirm('Data akan dihapus secara permanent, Lanjutkan?')">YA! Hapus Data</button>
            </div>
          </form>
          </div>
          
        </div>
        
      </div>
      

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
    $(function(){

        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });

        <?php if($message = Session::get('success')): ?>
        Toast.fire({
            icon: 'success',
            title: '<?php echo e($message); ?>'
        })
        <?php endif; ?>

        <?php if($message = Session::get('warning')): ?>
        Toast.fire({
            icon: 'warning',
            title: '<?php echo e($message); ?>'
        })
        <?php endif; ?>

        <?php if($message = Session::get('error')): ?>
        Toast.fire({
            icon: 'error',
            title: '<?php echo e($message); ?>'
        })
        <?php endif; ?>

    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\server dotapp\mti\submti\resources\views/admin/master/jabatan.blade.php ENDPATH**/ ?>