<?php $__env->startSection('pemasaran-open','menu-open'); ?>

<?php $__env->startSection('pemasaran-active','active'); ?>

<?php $__env->startSection('kontrak-active','active'); ?>

<?php $__env->startSection('content'); ?>

 
 <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12 mb-2">
          <h1>Edit Tarif</h1>
        </div>
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.index')); ?>">Pemasaran</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.index')); ?>">Kontrak</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.show',$tarif->store->kontrak->kontrak_id)); ?>"><?php echo e($tarif->store->kontrak->kontrak_klien_nama); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('tarif.show',$tarif->store->store_id)); ?>">Daftar Tarif <?php echo e($tarif->store->store_nama); ?></a></li>
            <li class="breadcrumb-item active">Edit Tarif</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="row">

      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Edit Tarif</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
            </div>
          </div>
          <div class="card-body">
            <form action="<?php echo e(route('tarif.update',$tarif->tarif_id)); ?>" method="POST"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

              <div class="form-group">
                  <label for="jkend">Jenis Kendaraan</label>
                  <select id="jkend" class="form-control select2bs4" name="jkend">
                      <option disabled>--Pilih Jenis Kendaraan--</option>
                      <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($j->jenis_kendaraan_id); ?>" <?php echo e($j->jenis_kendaraan_id == $tarif->jenis_kendaraan_id ? 'selected' : ''); ?>><?php echo e($j->jenis_kendaraan_nama); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>

              <div class="form-group">
                  <label for="tarif">Tarif Klien</label>
                  <input type="text" id="tarif" class="form-control uang" name="tarif" value="<?php echo e($tarif->tarif_klien); ?>">
              </div>

              

              

              <div class="form-group">
                  <label for="uj">Uang Jalan</label>
                  <input type="text" id="uj" class="form-control uang" name="uj" value="<?php echo e($tarif->tarif_mti_uang_jalan); ?>">
              </div>

              

              

              <div class="form-group">
                  <label for="ket">Keterangan</label>
                  <input type="text" id="ket" class="form-control" name="ket" value="<?php echo e($tarif->tarif_keterangan); ?>">
              </div>

            </div>
          </div>
          
        </div>
        
      </div>
      <div class="row">
        <div class="col-12">
          <a href="<?php echo e(route('tarif.show',$tarif->store_id)); ?>" class="btn btn-secondary">Batal</a>
          <input type="submit" value="Edit Tarif" class="btn btn-success float-right">
        </div>
      </div>
    </form>
  </section>
  

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
  <script>
  $(function () {
    // Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Date range picker
    $('#mulai').datetimepicker({
        format: 'L'
    });

    $('#selesai').datetimepicker({
        format: 'L'
    });
  })
  </script>

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.date').mask('00/00/0000');
      $('.uang').mask('000.000.000.000', {reverse: true});
      $('.time').mask('00:00:00');
      $('.date_time').mask('00/00/0000 00:00:00');
    });
  </script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/pemasaran/e_tarif.blade.php ENDPATH**/ ?>