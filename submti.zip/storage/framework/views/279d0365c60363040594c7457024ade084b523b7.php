<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan Gross Profit Armada</title>

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
</head>
<body class="text-xs">

  <div class="container">
    <div class="card">
      <div class="card-header">
        Laporan tertanggal : <?php echo e(\Carbon\Carbon::parse($dari)->format('d F Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($ke)->format('d F Y')); ?>

      </div>
      <div class="card-body">
        <h3 class="text-center">Laporan Gross Profit Armada</h3>
        <table class="table table-striped table-valign-middle text-nowrap">
          <thead>
          <tr>
            <th>Armada</th>
            <th>Revenue</th>
            <th>Expense</th>
            <th>Cicilan + Biaya</th>
            <th>Gross Profit</th>
          </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($kn->kendaraan_nopol); ?> - <?php echo e($kn->jenis->jenis_kendaraan_nama); ?></td>

              <?php $revenue = 0; $expense = 0; $gp = 0; ?>
              <?php $__currentLoopData = $budget->where('kendaraan_id',$kn->kendaraan_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $sj->where('budget_id',$b->budget_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sjk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $reconcile->where('surat_jalan_id',$sjk->surat_jalan_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                      $revenue += $rc->reconcile_klien_total;
                      $expense += $rc->reconcile_mti_total;
                    ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              
              <td>Rp <?php echo e(number_format($revenue,0,',','.')); ?></td>

              
              <td>Rp <?php echo e(number_format($expense,0,',','.')); ?></td>

              
              <?php
                $cicilan  = $kn->kendaraan_angsuran;
                $biaya    = $purchasing->where('kendaraan_id',$kn->kendaraan_id)->sum('purchasing_jumlah');
                $totalcb  = $cicilan + $biaya;
                $gp       = $revenue - ($expense + $totalcb);
              ?>
              <td>Rp <?php echo e(number_format($totalcb,0,',','.')); ?></td>

              
              <?php if($gp == 0): ?>
                <td class="text-dark">Rp <?php echo e(number_format($gp,0,',','.')); ?></td>
              <?php elseif($gp >= 0): ?>
                <td class="text-success">Rp <?php echo e(number_format($gp,0,',','.')); ?></td>
              <?php else: ?>
                <td class="text-danger">Rp <?php echo e(number_format($gp,0,',','.')); ?></td>
              <?php endif; ?>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>  
  </div>

</body>

<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
</html><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/laporan/laporan_gpa_cetak.blade.php ENDPATH**/ ?>