<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice</title>

     <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
</head>
<body class="text-xs">

    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12">
                <img class="img-fluid float-right" width="250px" src="<?php echo e(asset('MTI_Logo.png')); ?>" alt="">
            </div>
        </div>
        <div class="row mb-5">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger">
                        Sold To
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">PT. ALFAMART</h5>
                        <p class="card-text">jl.braga</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary">
                        Seller
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">PT.MARCOS TRANS INDONESIA</h5>
                        <p class="card-text">jl.WIJAYA KUSUMA</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center">INVOICE</h1>
                <h2 class="text-center">0002/Alfamart/MTI/JKT/V/2020</h2>
            </div>
        </div>
        <div class="card mb-5">
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Kota</th>
                        <th>Tipe Mobil</th>
                        <th>Nopol</th>
                        <th>Harga</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>20/8/2020</td>
                            <td>Bandung</td>
                            <td>CDD</td>
                            <td>B 777 LUK</td>
                            <td>Rp. 750.000</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>20/8/2020</td>
                            <td>Bandung</td>
                            <td>CDD</td>
                            <td>B 777 LUK</td>
                            <td>Rp. 750.000</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>20/8/2020</td>
                            <td>Bandung</td>
                            <td>CDD</td>
                            <td>B 777 LUK</td>
                            <td>Rp. 750.000</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>20/8/2020</td>
                            <td>Bandung</td>
                            <td>CDD</td>
                            <td>B 777 LUK</td>
                            <td>Rp. 750.000</td>
                        </tr>
                    </tbody>
                   <tfoot>
                       <tr>
                           <th colspan="5" class="text-right">Total Harga</th>
                           <td>Rp. 3.000.000</td>
                        </tr>
                        <tr>
                            <th colspan="5" class="text-right">ppn 10%</th>
                            <td>Rp. 300.000</td>
                        </tr>
                        <tr>
                            <th colspan="5" class="text-right">Grand Total</th>
                            <td>Rp. 3.300.000</td>
                        </tr>
                   </tfoot>
                </table>

            </div>
        </div>

        <div class="row">
            <div class="col-md-12 text-right">
                <p class="mb-5">
                    <b>
                        Bekasi, 20 Agustus 2020
                    </b>
                </p>
                <p class="">Nur Apica Putri<p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-left">
                <p class="">
                    <b>
                        BANK MANDIRI
                    </b>
                </p>
                <p class="">A/N: PT MARCOS TRANS INDONESIA<p>
                <p class="">A/C: 167xxxxxxx<p>
            </div>
        </div>


    </div>



<!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>



<!-- DataTables -->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(function () {
          $("#example1").DataTable({
              "scrollX":true,
          });
          $('#example2').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": false,
            "info": true,
            "autoWidth": false,
            "responsive": true,
          });
        });
      </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/operasional/l_invoice.blade.php ENDPATH**/ ?>