<?php $__env->startSection('menu-keuangan','menu-open'); ?>

<?php $__env->startSection('keuangan','active'); ?>

<?php $__env->startSection('invoice','active'); ?>

<?php $__env->startSection('content'); ?>

 
 <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12 mb-2">
          <h1>Tambah Invoice</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="#">Keuangan</a></li>
            <li class="breadcrumb-item"><a href="#">Manage Invoice</a></li>
            <li class="breadcrumb-item active">Tambah Invoice</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="row">

      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Tambah Invoice</h3>
            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
            </div>
          </div>
          <div class="card-body">

            <form action="<?php echo e(route('invoice.store')); ?>" method="POST"><?php echo csrf_field(); ?>

            <div class="form-group">
              <label for="kode">Kode Invoice</label>
              <input id="kode" class="form-control" type="text" name="kode">
            </div>
            
            <div class="form-group">
              <label for="kontrak">Kontrak</label>
              <select name="kontrak" id="kontrak" class="form-control select2bs4">
                <option selected disabled>-- Pilih Kontrak --</option>
                <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($k->kontrak_id); ?>"><?php echo e($k->kontrak_kode); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="form-group">
              <label for="tgl">Tanggal Invoice</label>
              <input id="tgl" class="form-control" type="date" name="tgl">
            </div>

            <div class="form-group">
              <label for="oleh">Cetak Oleh</label>
              <select name="oleh" id="oleh" class="form-control select2bs4">
                <option selected disabled>-- Pilih Karyawan --</option>
                <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($k->karyawan_id); ?>"><?php echo e($k->karyawan_nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

          </div>
        </div>
          
      </div>
      
    </div>
    <div class="row">
      <div class="col-12">
        <a href="<?php echo e(route('invoice.index')); ?>" class="btn btn-secondary">Batal</a>
        <input type="submit" value="Buat Invoice" class="btn btn-success float-right">
      </div>
    </div>
    </form>
  </section>
  

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
  
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
  <script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Date range picker
    $('#mulai').datetimepicker({
        format: 'L'
    });

    $('#selesai').datetimepicker({
        format: 'L'
    });
})
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/keuangan/i_invoice.blade.php ENDPATH**/ ?>