<?php $__env->startSection('menu-keuangan','menu-open'); ?>

<?php $__env->startSection('keuangan','active'); ?>

<?php $__env->startSection('payment','active'); ?>

<?php $__env->startSection('menu-payment','menu-open'); ?>

<?php if(isset($lunas)): ?>              
  <?php $__env->startSection('lunas','active'); ?>
<?php else: ?>
  <?php $__env->startSection('belumlunas','active'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6 mb-2">
            <h1>Manage Payment</h1>
          </div>
         <div class="col-sm-12">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#">Keuangan</a></li>
              <li class="breadcrumb-item active">Manage Payment</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    
    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <table id="example1" class="table table-striped text-nowrap" cellspacing="0" width="100%">
                  <thead>
                  <tr>
                    <th width="5%">No</th>
                    <th width="10%">Detail</th>
                    <th>No Invoice</th>
                    <th>Tanggal Invoice</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-right"><?php echo e($loop->iteration); ?></td>
                    <td class="text-center">
                      <a href="<?php echo e(route('payment.belum.show',$r->invoice_id)); ?>" class="btn btn-xs btn-link text-info" title="Detail Payment"><span class="fas fa-eye" ></span></a>
                    </td>
                    <td><?php echo e($r->invoice_kode); ?></td>
                    <td><?php echo e($r->invoice_tanggal); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </section>
    

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
        "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
  $(function(){

      const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
      });

      <?php if($message = Session::get('success')): ?>
      Toast.fire({
          icon: 'success',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      Toast.fire({
          icon: 'warning',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      Toast.fire({
          icon: 'error',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

  });
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/keuangan/v_payment.blade.php ENDPATH**/ ?>