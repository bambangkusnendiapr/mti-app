<?php $__env->startSection('menu-keuangan','menu-open'); ?>

<?php $__env->startSection('keuangan','active'); ?>

<?php $__env->startSection('payment','active'); ?>

<?php $__env->startSection('menu-payment','menu-open'); ?>

<?php if($invoice->invoice_status == 1): ?>              
  <?php $__env->startSection('lunas','active'); ?>
<?php else: ?>
  <?php $__env->startSection('belumlunas','active'); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>

    
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6 mb-2">
            <h1>Manage Detail Payment</h1>
          </div>
          <div class="col-sm-6">
            <a href="#" data-toggle="modal" data-target="#modal-tambah" class="btn btn-primary btn-sm float-right"><span class="fa fa-plus">&nbsp;</span>Tambah Detail Payment</a>
          </div>
         <div class="col-sm-12">
            <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="#">Keuangan</a></li>
              <li class="breadcrumb-item">Manage Payment</li>
              <li class="breadcrumb-item active">Detail Payment</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    
    <section class="content">
      <div class="container-fluid">

        <?php
          $total = 0;
          foreach($invoice->detail as $i){
            $total += $i->reconcile->reconcile_klien_total;
          }
        ?>
        
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <div class="row">

                <div class="col-3">
                  Total : Rp <?php echo e(number_format($total,0,',','.')); ?>

                </div>

                <div class="col-3">
                  Sisa : Rp <?php echo e(number_format($total - $payment->sum('payment_bayar'),0,',','.')); ?>

                </div>

                <div class="col-3">
                  Jumlah Cicilan : <?php echo e($payment->count()); ?>

                </div>

                <div class="col-3">
                  <?php if($payment->sum('payment_bayar') <= $total && $invoice->invoice_status != 1): ?>
                    <a href="#" class="btn btn-xs btn-link text-danger"><i class="fas fa-times"></i> Belum Lunas</a>
                  <?php endif; ?>
                  <?php if($payment->sum('payment_bayar') >= $total && $invoice->invoice_status != 1): ?>
                    <a href="<?php echo e(route('payment.belum.lunas',$invoice->invoice_id)); ?>" class="btn btn-xs btn-link text-warning"><i class="fas fa-exclamation"></i> Tekan Jika Sudah Lunas</a>
                  <?php endif; ?>
                  <?php if($invoice->invoice_status == 1): ?>
                    <a href="#" class="btn btn-xs btn-link text-success"><i class="fas fa-check"></i> Lunas</a>
                  <?php endif; ?>
                </div>

                </div>

              </div>
            </div>
          </div>
        </div>

        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <table id="example1" class="table table-striped text-nowrap" cellspacing="0" width="100%">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Jumlah Bayar</th>
                    <th>Tanggal Bayar</th>
                    <?php if($invoice->invoice_status != 1): ?>
                    <th></th>
                    <?php endif; ?>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-right"><?php echo e($loop->iteration); ?></td>
                    <td>Rp <?php echo e(number_format($r->payment_bayar,0,',','.')); ?></td>
                    <td><?php echo e($r->payment_tanggal); ?></td>
                    <?php if($invoice->invoice_status != 1): ?>
                    <td class="text-center">
                      <a href="#" data-target="#modal-edit<?php echo e($r->payment_id); ?>" data-toggle="modal" class="btn btn-xs btn-link"  title="Edit"><span class="fa fa-edit" ></span></a>
                      <a href="#" data-target="#modal-hapus<?php echo e($r->payment_id); ?>" data-toggle="modal" class="btn btn-xs btn-link" title="Hapus"><span class="fa fa-trash"></span></a>
                    </td>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </section>
    

  <div class="modal fade" id="modal-tambah">
    <div class="modal-dialog">
      <div class="modal-content">
      <form action="<?php echo e(route('payment.belum.store')); ?>" method="POST"> <?php echo csrf_field(); ?>
        <div class="modal-header bg-primary">
          <h4 class="modal-title">Tambah Detail Payment</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="payment">Bayar</label>
              <input type="text" name="payment" class="form-control uang" id="payment" required>
          </div>
          <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" name="tanggal" class="form-control" id="tanggal">
          </div>
          <input type="hidden" name="invoice" value="<?php echo e($invoice->invoice_id); ?>">
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-success">Tambah</button>
        </div>
      </form>
      </div>
      
    </div>
    
  </div>
  

  <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-edit<?php echo e($r->payment_id); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
      <form action="<?php echo e(route('payment.belum.update',$r->payment_id)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="modal-header bg-primary">
          <h4 class="modal-title">Edit Detail Payment</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo csrf_field(); ?>
          <div class="form-group">
              <label for="payment">Bayar</label>
              <input type="text" name="payment" class="form-control uang" id="payment" value="<?php echo e($r->payment_bayar); ?>">
          </div>
          <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" name="tanggal" class="form-control" id="tanggal" value="<?php echo e($r->payment_tanggal); ?>">
          </div>
          <input type="hidden" name="invoice" value="<?php echo e($invoice->invoice_id); ?>">
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-success">Edit</button>
        </div>
      </form>
      </div>
      
    </div>
    
  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="modal-hapus<?php echo e($r->payment_id); ?>">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="<?php echo e(route('payment.delete',$r->payment_id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <div class="modal-header bg-danger">
            <h4 class="modal-title">Peringatan</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body text-center text=danger">
            <h3>Apakah anda yakin ingin menghapus detail Invoice ? <?php echo e($r->payment_id); ?></h3>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-danger">YA! Hapus Data</button>
          </div>
          </form>
        </div>
        
      </div>
      
    </div>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
        "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
  $(function(){

      const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
      });

      <?php if($message = Session::get('success')): ?>
      Toast.fire({
          icon: 'success',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      Toast.fire({
          icon: 'warning',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      Toast.fire({
          icon: 'error',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

  });
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.date').mask('00/00/0000');
    $('.uang').mask('000.000.000.000', {reverse: true});
    $('.time').mask('00:00:00');
    $('.date_time').mask('00/00/0000 00:00:00');
  });
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/keuangan/d_payment.blade.php ENDPATH**/ ?>