<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('content'); ?>


<section class="content-header">
   <div class="container-fluid">
     <div class="row mb-2">
       <div class="col-sm-6">
         <h1>Dashboard</h1>
       </div>
       <div class="col-sm-6">
         <ol class="breadcrumb float-sm-right">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active">Dashboard</li>
         </ol>
       </div>
     </div>
   </div>
 </section>

 
 <section class="content">

  
  <div class="row">
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-info">
        <div class="inner">
          <h3><?php echo e($kontrak->count()); ?></h3>

          <p>Kontrak</p>
        </div>
        <div class="icon">
          <i class="fas fa-file"></i>
        </div>
        <a href="<?php echo e(route('kontrak.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-success">
        <div class="inner">
          <h3><?php echo e($sj->count()); ?></h3>

          <p>Ritase</p>
        </div>
        <div class="icon">
          <i class="fas fa-paper-plane"></i>
        </div>
        <a href="<?php echo e(route('suratjalan.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-warning">
        <div class="inner">
          <h3>44</h3>

          <p>User Registrations</p>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-danger">
        <div class="inner">
          <h3>65</h3>

          <p>Unique Visitors</p>
        </div>
        <div class="icon">
          <i class="ion ion-pie-graph"></i>
        </div>
        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    
  </div>
  
  
  <div class="row">
    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Gross Profit</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Penghasilan</th>
              <th>Pengeluaran</th>
              <th>Total</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php $pendapatan = 0; $pengeluaran = 0; $total = 0; ?>
              
              <?php $__currentLoopData = $invoice->where('kontrak_id',$k->kontrak_id)->where('invoice_status',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                  foreach($r->detail as $i){
                    $pendapatan   = $i->reconcile->sum('reconcile_klien_total');
                    $pengeluaran  = $i->reconcile->sum('reconcile_mti_total'); 
                  }
                  $total = $total + ($pendapatan - $pengeluaran);
                ?>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($pengeluaran,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    

    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Ritase</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Jumlah</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td><?php echo e($sj->where('kontrak_id',$k->kontrak_id)->count()); ?></td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    
  </div>
  

  <div class="row">
    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Account Receiveable</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Kode Invoice</th>
              <th>Total Belum Bayar</th>
              <th>Usia Invoice</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php $pendapatan = 0; $pengeluaran = 0; $total = 0; ?>
              
              <?php $__currentLoopData = $invoice->where('kontrak_id',$k->kontrak_id)->where('invoice_status','!=',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                  foreach($r->detail as $i){
                    $pendapatan   = $i->reconcile->sum('reconcile_klien_total');
                  }
                ?>
              
              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td><?php echo e($r->invoice_kode); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan - $r->payment->sum('payment_bayar'),0,',','.')); ?></td>
                <td><?php echo e(\Carbon\Carbon::createFromDate($r->invoice_tanggal)->diffForHumans()); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    

    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Account Payable</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Patner</th>
              <th>Jumlah Bayar</th>
              <th>Total Belum Bayar</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $tap = 0; $lsisa = 0; $lbayar = 0; $count = 0;
            ?>

            <?php $__currentLoopData = $leasing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $count    = $r->payment->count();
                $lbayar   += $count * $r->kendaraan->kendaraan_angsuran;
                $lsisa    += ( $r->kendaraan->kendaraan_jangka_sisa - $count ) * $r->kendaraan->kendaraan_angsuran;
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td>Leasing</td>
                <td>Rp <?php echo e(number_format($lbayar,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($lsisa,0,',','.')); ?></td>
              </tr>

            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $jumlah = 0; $total = 0; ?>
              <?php $__currentLoopData = $p->ap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $jumlah += $ap->payment->sum('payment_partner_jumlah');
                  $total  = $p->ap->sum('purchasing_jumlah') - $jumlah;
                  $tap    += $total;
                ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($p->partner_nama); ?></td>
                <td>Rp <?php echo e(number_format($jumlah,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3"><strong>Total AP : </strong>Rp <?php echo e(number_format($tap + $lsisa,0,',','.')); ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
        
      </div>
      
    </div>
    
  </div>
  

 </section>
 

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  
  <script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

  
  <script>
    $(function () {
      $("#example1").DataTable({
          "scrollX": true
      });
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": true,
        "responsive": false,

      });
    });
  </script>

<?php $__env->stopPush(); ?>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>