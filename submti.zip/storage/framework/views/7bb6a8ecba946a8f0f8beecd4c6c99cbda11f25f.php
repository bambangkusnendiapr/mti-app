
  
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    
    <a href="/" class="brand-link">
      <img src="<?php echo e(asset('admin/dist/img/AdminLTELogo.png')); ?>"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">MTI</span>
    </a>

    
    <div class="sidebar">
      
      

      
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar nav-child-indent flex-column"  data-widget="treeview" role="menu" data-accordion="false">
    
            <li class="nav-item has-treeview">
                <a href="/dashboard" class="nav-link <?php echo $__env->yieldContent('dashboard'); ?> ">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Dashboard
                    </p>
                </a>
            </li>

            <?php if (app('laratrust')->ability('owner,admin,lord','*')) : ?>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('pemasaran-open'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('pemasaran-active'); ?>">
                    <i class="nav-icon fa fa-file"></i>
                    <p>
                        Pemasaran
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('kontrak.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kontrak-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Kontrak</p>
                        </a>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('menu-op'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('op'); ?>">
                    <i class="nav-icon fa fa-truck"></i>
                    <p>
                        Operasional
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    
                    <li class="nav-item has-treeview">
                        <a href="<?php echo e(route('persetujuanbudget.index')); ?>" class="nav-link <?php echo $__env->yieldContent('po'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Persetujuan Budget</p>
                        </a>
                    </li>

                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('menu-keuangan'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('keuangan'); ?>">
                    <i class="nav-icon fa fa-balance-scale" ></i>
                    <p>
                        Keuangan
                    <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('suratjalan.index')); ?>" class="nav-link <?php echo $__env->yieldContent('reconcile'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Surat Jalan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('invoice.index')); ?>" class="nav-link <?php echo $__env->yieldContent('invoice'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Invoice</p>
                        </a>
                    </li>

                    <li class="nav-item <?php echo $__env->yieldContent('menu-payment'); ?>">
                        <a href="#" class="nav-link <?php echo $__env->yieldContent('payment'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Payment<i class="right fas fa-angle-left"></i></p>
                        </a>
                        
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('payment.belum.index')); ?>" class="nav-link <?php echo $__env->yieldContent('belumlunas'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Belum Lunas</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('payment.lunas.index')); ?>" class="nav-link <?php echo $__env->yieldContent('lunas'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lunas</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('akuntansi-menu'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('akuntansi-active'); ?>">
                    <i class="nav-icon fas fa-dollar-sign"></i>
                    <p>
                        Akuntansi
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                
                <ul class="nav nav-treeview">

                    <li class="nav-item <?php echo $__env->yieldContent('siklus-menu'); ?>">
                        <a href="#" class="nav-link <?php echo $__env->yieldContent('siklus-active'); ?>">
                            <i class="fas fa-calculator nav-icon"></i>
                            <p>
                                Siklus
                                <i class="right fas fa-angle-left"></i>
                            </p>
                        </a>
                        
                        <ul class="nav nav-treeview">

                            <li class="nav-item">
                                <a href="<?php echo e(route('kode-akun.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kode-akun'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Kode Akun</p>
                                </a>
                            </li>
        
                            <li class="nav-item">
                                <a href="<?php echo e(route('posting.index')); ?>" class="nav-link <?php echo $__env->yieldContent('posting'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Jurnal</p>
                                </a>
                            </li>
        
                            <li class="nav-item">
                                <a href="/akuntansi/laporan" class="nav-link <?php echo $__env->yieldContent('laporan'); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Laporan Akuntansi</p>
                                </a>
                            </li>

                        </ul>
                    </li>

                    

                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('other-open'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('other-active'); ?>">
                  <i class="nav-icon fa fa-archive"></i>
                  <p>
                    Others
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('payroll-periode.index')); ?>" class="nav-link <?php echo $__env->yieldContent('payroll'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Payroll</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('leasing.index')); ?>" class="nav-link <?php echo $__env->yieldContent('leasing'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Leasing</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('purchasing.index')); ?>" class="nav-link <?php echo $__env->yieldContent('purchasing'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Purchasing</p>
                        </a>
                    </li>

                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('laporan-open'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('laporan-active'); ?>">
                  <i class="nav-icon fa fa-archive"></i>
                  <p>
                    Laporan
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('laporan.sj.index')); ?>" class="nav-link <?php echo $__env->yieldContent('laporan-sj'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Laporan Surat Jalan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('laporan.omset.index')); ?>" class="nav-link <?php echo $__env->yieldContent('laporan-omset'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Laporan Omset</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('laporan.ar.index')); ?>" class="nav-link <?php echo $__env->yieldContent('laporan-ar'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Laporan AR</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('laporan.ap.index')); ?>" class="nav-link <?php echo $__env->yieldContent('laporan-ap'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Laporan AP</p>
                        </a>
                    </li>

                </ul>
            </li>

            <li class="nav-item has-treeview <?php echo $__env->yieldContent('master-open'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('master-active'); ?>">
                  <i class="nav-icon fa fa-database"></i>
                  <p>
                    Master Data
                    <i class="right fas fa-angle-left"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">

                    <li class="nav-item">
                        <a href="<?php echo e(route('driver.index')); ?>" class="nav-link <?php echo $__env->yieldContent('driver-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Driver</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('kendaraan.index')); ?>" class="nav-link <?php echo $__env->yieldContent('kendaraan-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Kendaraan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('jeniskendaraan.index')); ?>" class="nav-link <?php echo $__env->yieldContent('jeniskendaraan-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Jenis Kendaraan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('karyawan.index')); ?>" class="nav-link <?php echo $__env->yieldContent('karyawan-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Karyawan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('region.index')); ?>" class="nav-link <?php echo $__env->yieldContent('region-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Region</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('jabatan.index')); ?>" class="nav-link <?php echo $__env->yieldContent('jabatan-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Jabatan</p>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="<?php echo e(route('partner.index')); ?>" class="nav-link <?php echo $__env->yieldContent('partner-active'); ?>">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Master Partner</p>
                        </a>
                    </li>

                </ul>
            </li>
            <?php endif; // app('laratrust')->ability ?>

            <?php if (app('laratrust')->hasRole('user')) : ?>
            
            <li class="nav-item has-treeview <?php echo $__env->yieldContent('menu-op'); ?>">
                <a href="#" class="nav-link <?php echo $__env->yieldContent('op'); ?>">
                  <i class="nav-icon fa fa-truck"></i>
                    <p>
                        Operasional
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">

                  <li class="nav-item has-treeview">
                    <a href="<?php echo e(route('po.index')); ?>" class="nav-link <?php echo $__env->yieldContent('po'); ?>">
                        <i class="far fa-circle nav-icon"></i>
                        <p>Pengajuan Budget</p>
                    </a>
                  </li>

                  

                  <li class="nav-item">
                      <a href="<?php echo e(route('sj.index')); ?>" class="nav-link <?php echo $__env->yieldContent('sj'); ?>">
                          <i class="far fa-circle nav-icon"></i>
                          <p>Surat Jalan</p>
                      </a>
                  </li>

                  

                </ul>
            </li>
            
            <?php endif; // app('laratrust')->hasRole ?>

            <li class="nav-item has-treeview">
                <a href="#" class="nav-link">
                    <i class="nav-icon fa fa-cog"></i>
                    <p>
                        Pengaturan
                        <i class="right fas fa-angle-left"></i>
                    </p>
                </a>
                <ul class="nav nav-treeview">
                    <li class="nav-item">
                        <a href="/klien" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Profil</p>
                        </a>
                    </li>
                    <?php if (app('laratrust')->hasRole('lord')) : ?>
                    <li class="nav-item">
                        <a href="/klien" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage User</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="/kontrak" class="nav-link">
                            <i class="far fa-circle nav-icon"></i>
                            <p>Manage Role</p>
                        </a>
                    </li>
                    <?php endif; // app('laratrust')->hasRole ?>
                </ul>
            </li>

            <li class="nav-item">
                <a href="/logout" class="nav-link">
                    <i class="nav-icon fas fa-sign-out-alt"></i>
                    <p>
                        Sign Out
                    </p>
                </a>
            </li>

        </ul>
      </nav>
      
    </div>
    
  </aside>
<?php /**PATH C:\xampp\htdocs\MTI\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>