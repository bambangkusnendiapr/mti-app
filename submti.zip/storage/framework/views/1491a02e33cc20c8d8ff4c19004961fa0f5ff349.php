<?php $__env->startSection('pemasaran-open','menu-open'); ?>

<?php $__env->startSection('pemasaran-active','active'); ?>

<?php $__env->startSection('kontrak-active','active'); ?>

<?php $__env->startSection('content'); ?>

 
 <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12 mb-2">
          <h1>Tambah Tarif</h1>
        </div>
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.index')); ?>">Pemasaran</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.index')); ?>">Kontrak</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('kontrak.show',$store->kontrak->kontrak_id)); ?>"><?php echo e($store->kontrak->kontrak_klien_nama); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('tarif.show',$store->store_id)); ?>">Daftar Tarif <?php echo e($store->store_nama); ?></a></li>
            <li class="breadcrumb-item active">Tambah Tarif</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="row">

      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Tambah Tarif</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
            </div>
          </div>
          <div class="card-body">
            <form action="<?php echo e(route('tarif.store')); ?>" method="POST"><?php echo csrf_field(); ?>

                <input type="hidden" name="store" value="<?php echo e($store->store_id); ?>">

                <div class="form-group">
                    <label for="jkend">Jenis Kendaraan</label>
                    <select id="jkend" class="form-control select2bs4" name="jkend">
                        <option disabled selected>--Pilih Jenis Kendaraan--</option>
                        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($j->jenis_kendaraan_id); ?>"><?php echo e($j->jenis_kendaraan_nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tarif">Tarif Klien</label>
                    <input type="text" id="tarif" class="form-control uang" name="tarif">
                </div>

                

                

                <div class="form-group">
                    <label for="uj">Uang Jalan</label>
                    <input type="text" id="uj" class="form-control uang" name="uj">
                </div>

                

                

                <div class="form-group">
                    <label for="ket">Keterangan</label>
                    <input type="text" id="ket" class="form-control" name="ket">
                </div>

            </div>
          </div>
          
        </div>
        
      </div>
    <div class="row">
      <div class="col-12">
        <a href="/kontrak" class="btn btn-secondary">Batal</a>
        <input type="submit" value="Tambah Tarif" class="btn btn-success float-right">
      </div>
    </div>
    </form>
  </section>
  

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


  
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
  <script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Date range picker
    $('#mulai').datetimepicker({
        format: 'L'
    });

    $('#selesai').datetimepicker({
        format: 'L'
    });
  })
  </script>

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.date').mask('00/00/0000');
      $('.uang').mask('000.000.000.000', {reverse: true});
      $('.time').mask('00:00:00');
      $('.date_time').mask('00/00/0000 00:00:00');
     });
  </script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/pemasaran/i_tarif.blade.php ENDPATH**/ ?>