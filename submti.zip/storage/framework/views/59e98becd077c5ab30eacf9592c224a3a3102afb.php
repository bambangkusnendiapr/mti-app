<?php $__env->startSection('menu-op','menu-open'); ?>

<?php $__env->startSection('op','active'); ?>

<?php $__env->startSection('po','active'); ?>

<?php $__env->startSection('content'); ?>

 <!-- Content Header (Page header) -->
 <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12 mb-2">
          <h1>Tambah Store</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="#">Operasional</a></li>
            <li class="breadcrumb-item"><a href="#">Manage PO</a></li>
            <li class="breadcrumb-item"><a href="#">Budgeting</a></li>
            <li class="breadcrumb-item">Store</li>
            <li class="breadcrumb-item active">Tambah Store</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">

      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Tambah Store</h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                <i class="fas fa-minus"></i></button>
            </div>
          </div>
          <div class="card-body">
            <form action="#" method="POST"><?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="col-md-2">
                        <label for="inputStatus">Pilih Jenis Store</label>
                    </div>
                    <div class="col-md-10">
                        <select class="form-control select2bs4" name="js">
                          <option selected disabled>--Pilih Jenis Store--</option>
                          <option>KCN</option>
                          <option>JKT</option>
                          <option>BDG</option>
                        </select>
                    </div>
                </div>
                <hr>
                <div class="row">

                    <div class="col-md-3">
                        <label for="">Tarif Klien</label>
                    </div>
                    <div class="col-md-3">
                        <label for="">500.000</label>
                    </div>

                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="tariftambah">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="tariftambah">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Multidrop Klien</label>
                    </div>

                    <div class="col-md-3">
                        <div class="form-check">
                            <input id="mdkly" class="form-check-input" type="checkbox" name="" value="true">
                            <label for="mdkly" class="form-check-label">Multidrop Dalam Kota <strong>25.000</strong></label>
                        </div>
                        <div class="form-check">
                            <input id="mdkly" class="form-check-input" type="checkbox" name="" value="true">
                            <label for="mdkly" class="form-check-label">Multidrop Luar Kota <strong>50.000</strong></label>
                        </div>
                    </div>
                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mdklmod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="mdklmod">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Bongkar Muat Klien</label>
                    </div>

                    <div class="col-md-3">
                        <label for="">10.000</label>
                    </div>
                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="bmkmod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="bmkmod">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Biaya Lain Klien</label>
                    </div>

                    <div class="col-md-3">
                    <div class="form-group">
                        <input id="laink" class="form-control" type="text" name="" placeholder="keterangan">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="laink">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="laink">
                        </div>
                    </div>

                </div>
                <hr>

                <div class="row">
                    <div class="col-md-3">
                        <label for="">Uang Jalan</label>
                    </div>

                    <div class="col-md-3">
                        <label for="">250.000</label>
                    </div>

                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="ujmod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="ujmod">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Multidrop Supir</label>
                    </div>

                    <div class="col-md-3">
                        <div class="form-check">
                            <input id="mdkly" class="form-check-input" type="checkbox" name="" value="true">
                            <label for="mdkly" class="form-check-label">Multidrop Dalam Kota <strong>25.000</strong></label>
                        </div>
                        <div class="form-check">
                            <input id="mdkly" class="form-check-input" type="checkbox" name="" value="true">
                            <label for="mdkly" class="form-check-label">Multidrop Luar Kota <strong>50.000</strong></label>
                        </div>
                    </div>

                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mdmlmod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="mdmlmod">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Bongkar Muat</label>
                    </div>

                    <div class="col-md-3">
                        <label for="">50.000</label>
                    </div>

                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="bkmm">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="bkmm">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Ritase</label>
                    </div>

                    <div class="col-md-3">
                        <label for="">50.000</label>
                    </div>

                    <div class="col-md-6 mb-2">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="ritasemod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="ritasemod">
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label for="">Biaya Lain Supir</label>
                    </div>

                    <div class="col-md-3">
                    <div class="form-group">
                        <input id="laink" class="form-control" type="text" name="" placeholder="keterangan">
                    </div>
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="bmkmod">+/-</span>
                            </div>
                            <input class="form-control" type="number" name="" placeholder="" aria-label="Recipient's " aria-describedby="bmkmod">
                        </div>
                    </div>

                </div>

            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    <div class="row">
      <div class="col-12">
        <a href="<?php echo e(route('budgetstore.index')); ?>" class="btn btn-secondary">Batal</a>
        <input type="submit" value="Tambah Store" class="btn btn-success float-right">
      </div>
    </div>
    </form>
  </section>
  <!-- /.content -->




<?php $__env->startPush('css'); ?>
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  <!-- daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  <!-- Select2 -->
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <!-- date-range-picker -->
  <script src="<?php echo e(asset('admin/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
  <script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Date range picker
    $('#mulai').datetimepicker({
        format: 'L'
    });

    $('#selesai').datetimepicker({
        format: 'L'
    });
})
</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/operasional/i_budgetstore.blade.php ENDPATH**/ ?>