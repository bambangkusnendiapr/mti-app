<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan Surat Jalan</title>

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
</head>
<body class="text-xs">

  <div class="container">
    <div class="card">
      <div class="card-header">
        Laporan tertanggal : <?php echo e(\Carbon\Carbon::parse($dari)->format('d F Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($ke)->format('d F Y')); ?>

      </div>
      <div class="card-body">
        <h3 class="text-center">Laporan Surat Jalan Belum Kembali</h3>
        <table class="table table-light table-striped table-bordered">
          <thead>
            <tr>
              <th>No</th>
              <th>Kontrak</th>
              <th>Surat Jalan ID</th>
              <th>Tanggal Surat Jalan</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>   
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($r->kontrak->kontrak_kode); ?></td>
              <td><?php echo e($r->surat_jalan_id); ?></td>
              <td><?php echo e($r->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="4" class="text-center">No Data</td>
            </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>  
  </div>

</body>

<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
</html><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/laporan/laporan_sj_cetak.blade.php ENDPATH**/ ?>