<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>MTI | Log in</title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<div class="hold-transition login-page">
  <div class="login-box">
    <div class="login-logo">
      <img src="<?php echo e(asset('MTI_logo.png')); ?>" width="75%" height="75%">
    </div>
    

    <div class="login-box-body">
      <div class="card">
        <?php if($message = Session::get('store')): ?>
          <div class="card-header text-center"><?php echo e($message); ?></div>
        <?php endif; ?>
        <div class="card-body login-card-body">
          
          <form action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>

            <div class="input-group mb-3">
              <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Username" required autofocus>
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-user"></span>
                </div>
              </div>
                <?php if($errors->has('email')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="input-group mb-3">
              <input id="password-field" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>
              <div class="input-group-append">
                <div class="input-group-text">
                  <span class="fas fa-lock"></span>
                </div>
              </div>
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>

            <div class="row">
              <div class="col-8">
                <span toggle="#password-field" class="fa fa-eye toggle-password"> Show / Hide Password</span>
              </div>
              
              <div class="col-4">
                <button type="submit" class="btn btn-primary btn-block btn-flat"><span class="fas fa-sign-in-alt"></span> Sign In</button>
              </div>
              
            </div>
          </form>
          

        </div>
        
      </div>
    </div>
  </div>
  
</div>


<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.js')); ?>"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });

  $(".toggle-password").click(function() {

    $(this).toggleClass("fa-eye fa-eye-slash");
        var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
  });
</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\MTI\resources\views/auth/login.blade.php ENDPATH**/ ?>