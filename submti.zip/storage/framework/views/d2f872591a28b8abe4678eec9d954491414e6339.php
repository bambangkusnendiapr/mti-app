<?php $__env->startSection('menu-op','menu-open'); ?>

<?php $__env->startSection('op','active'); ?>

<?php $__env->startSection('po','active'); ?>

<?php $__env->startSection('content'); ?>

  
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6 mb-2">
          <h1>Persetujuan Budget</h1>
        </div>
        <div class="col-sm-6">
          

        </div>
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
            <li class="breadcrumb-item"><a href="#">Operasional</a></li>
            <li class="breadcrumb-item active">Persetujuan Budget</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="container-fluid">
      <div class="row">

        <div class="col-12">
          <div class="card">
            
            
            <div class="card-body">
              <form action="<?php echo e(route('persetujuanbudget.update',$budget->budget_id)); ?>" method="post">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="row">

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="tarif">Tarif</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text bg-success" id="tarif">Rp</span>
                        </div>
                        <input id="tarif" class="form-control bg-white" type="text" name="tarif" value="<?php echo e($budget->bstore->max('budgetstore_klien_tarif')); ?>" readonly>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="tarifed">&nbsp;</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="tarifed">+/-</span>
                        </div>
                        <input id="tarifed" class="form-control" type="number" name="tarifed" value="<?php echo e($budget->budget_tarif - $budget->bstore->max('budgetstore_klien_tarif')); ?>">
                      </div>
                    </div>
                  </div>

                </div>

                <div class="row">

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="uj">Uang Jalan</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text bg-success" id="uj">Rp</span>
                        </div>
                        <input id="uj" class="form-control bg-white" type="text" name="uj" value="<?php echo e($budget->bstore->max('budgetstore_mti_uang_jalan')); ?>" readonly>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="ujed">&nbsp;</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="ujed">+/-</span>
                        </div>
                        <input id="ujed" class="form-control" type="number" name="ujed" value="<?php echo e($budget->budget_uang_jalan - $budget->bstore->max('budgetstore_mti_uang_jalan')); ?>">
                      </div>
                    </div>
                  </div>

                </div>

                <div class="row">

                  <?php
                    if($budget->budget_mdi != null){
                    
                      $mdi          = 0;
                      $jstore       = $budget->bstore->count();
                      $mdi_tambahan = $jstore - $budget->po->po_mdi_ke;
                      
                      if($jstore > $budget->po->po_mdi_ke){
                        $mdi = $budget->po->po_mdi_dasar + ($mdi_tambahan * $budget->po->po_mdi_tambahan);
                      }

                    }else{
                      $mdi = $budget->budget_mdi;
                    }

                    if($budget->budget_mdk != null){
                    
                      $mdk          = 0;
                      $jstore       = $budget->bstore->count();
                      $mdk_tambahan = $jstore - $budget->po->po_mdk_ke;
                      
                      if($jstore > $budget->po->po_mdk_ke){
                        $mdk = $budget->po->po_mdk_dasar + ($mdk_tambahan * $budget->po->po_mdk_tambahan);
                      }

                    }else{
                      $mdk = $budget->budget_mdk;
                    }

                  ?>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="mdk">MDK</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text bg-success" id="mdk">Rp</span>
                        </div>
                        <input id="mdk" class="form-control bg-white" type="text" name="mdk" value="<?php echo e($mdk); ?>" readonly>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="mdked">&nbsp;</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="mdked">+/-</span>
                        </div>
                        <input id="mdked" class="form-control" type="number" name="mdked" value="<?php echo e($budget->budget_mdk - $mdk); ?>">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="mdi">MDI</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text bg-success" id="mdi">Rp</span>
                        </div>
                        <input id="mdi" class="form-control bg-white" type="text" name="mdi" value="<?php echo e($mdi); ?>" readonly>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="mdied">&nbsp;</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text" id="mdied">+/-</span>
                        </div>
                        <input id="mdied" class="form-control" type="number" name="mdied" value="<?php echo e($budget->budget_mdi - $mdi); ?>">
                      </div>
                    </div>
                  </div>

                </div>

                <input type="submit" value="Setujui" class="btn btn-primary float-right ">
                <input type="Reset" value="Batal" class="btn btn-danger float-left ">

              </form>
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </div>
    
  </section>
  




<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
        "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/operasional/pusat/e_persetujuan.blade.php ENDPATH**/ ?>