<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Laba Rugi</title>

     <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
</head>
<body>
    <div class="container">
        <h1 class="mb-5">Laba Rugi</h1>
        <div class="row ">
          <label>PENDAPATAN USAHA</label>
          <table class="table mb-5 text-nowrap" width="100%">
            <thead>
              <tr>
                <td width="150px">Kode Akun</td>
                <td width="150px">Nama Akun</td>
                <td width="150px">Saldo</td>
              </tr>
            </thead>
            <tbody>
              <?php $kredit = 0; ?>
              <?php $__currentLoopData = $trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($r->akun->kode_akun >= 4000 && $r->akun->kode_akun <= 5999 && $r->akun->kelompok == "LABA RUGI"): ?>
                  <?php $__currentLoopData = $transaksi->where('kode_akun',$r->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $kredit += $k->kredit ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td width="150px"><?php echo e($r->akun->kode_akun); ?></td>
                      <td width="150px"><?php echo e($r->akun->nama_akun); ?></td>
                      <td width="150px"><?php echo e(number_format($r->where('kode_akun',$k->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('kredit'),0,',','.')); ?></td>
                    </tr>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
              <tfoot class="bg-danger">
                  <th colspan="2">TOTAL PENDAPATAN USAHA</th>
                  <td><?php echo e(number_format($kredit,0,',','.')); ?></td>
              </tfoot>
            </table>

            
            <label>BIAYA UMUM & ADMINISTRASI</label>
            <table class="table mb-5 text-nowrap" width="100%">
              <thead>
                <tr>
                  <td width="150px">Kode Akun</td>
                  <td width="150px">Nama Akun</td>
                  <td width="150px">Saldo</td>
                </tr>
              </thead>
              <tbody>
                <?php $debet = 0; ?>
                <?php $__currentLoopData = $trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($r->akun->kode_akun >= 6000 && $r->akun->kode_akun <= 6999 && $r->akun->kelompok == "LABA RUGI"): ?>
                    <?php $__currentLoopData = $transaksi->where('kode_akun',$r->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php $debet += $d->debet ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td width="150px"><?php echo e($r->akun->kode_akun); ?></td>
                      <td width="150px"><?php echo e($r->akun->nama_akun); ?></td>
                      <td width="150px"><?php echo e(number_format($r->where('kode_akun',$d->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('debet'),0,',','.')); ?></td>
                    </tr>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr class="bg-warning">
                  <th colspan="2">TOTAL BIAYA</th>
                  <th ><?php echo e(number_format($debet,0,',','.')); ?></th>
                </tr>
                <tr>
                  <th></th>
                  <th></th>
                </tr>
                <tr class="bg-primary">
                  <th colspan="2">TOTAL LABA RUGI</th>
                  <th ><?php echo e(number_format($kredit - $debet,0,',','.')); ?></th>
                </tr>
              </tfoot>
            </table>
            

        </div>
    </div>



<!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>



<!-- DataTables -->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(function () {
          $("#example1").DataTable({
              "scrollX":true,
          });
          $('#example2').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": false,
            "ordering": false,
            "info": false,
            "autoWidth": false,
            "responsive": false,
          });
        });
      </script>
</body>
</html>
<?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/akuntansi/laba_rugi.blade.php ENDPATH**/ ?>