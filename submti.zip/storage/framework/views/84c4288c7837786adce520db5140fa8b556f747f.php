<?php $__env->startSection('menu-op','menu-open'); ?>

<?php $__env->startSection('op','active'); ?>

<?php $__env->startSection('sj','active'); ?>

<?php $__env->startSection('content'); ?>

  
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6 mb-2">
          <h1>Manage Surat Jalan</h1>
        </div>
        
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="#">Operasional</a></li>
            <li class="breadcrumb-item active">Manage Surat Jalan</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="container-fluid">
      <div class="row">

        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <table id="example1" class="table table-striped" width="100%" cellspacing="0">
                <thead>
                <tr>
                  <th>No</th>
                  <th>KD PO</th>
                  <th>Jenis Kendaraan</th>
                  <th>No Polisi</th>
                  <th>Nama Driver</th>
                  <th>Barang</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $sj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-right"><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($r->budget->po->po_kode); ?></td>
                  <td><?php echo e($r->budget->jenis->jenis_kendaraan_nama); ?></td>
                  <td><?php echo e($r->budget->kendaraan->kendaraan_nopol); ?></td>
                  <td><?php echo e($r->budget->driver->driver_nama); ?></td>
                  <td>
                    <a href="<?php echo e(route('sjbarang.show',$r->surat_jalan_id)); ?>" data-target="" data-toggle="" class="btn btn-xs btn-link text-dark" title="Detail"><span class="fa fa-boxes" ></span></a>
                  </td>
                  <td class="row text-right">
                    <div class="btn-group">
                      <a href="<?php echo e(route('sj.cetak',$r->surat_jalan_id)); ?>" class="btn btn-xs btn-link text-primary" title="Cetak Surat Jalan"><span class="fas fa-print"></span></a>
                      <?php if($r->surat_jalan_status == null): ?>
                        <a href="<?php echo e(route('sj.terima',$r->surat_jalan_id)); ?>" class="btn btn-xs btn-link text-info" title="Kirim Surat Jalan" onclick="return confirm('Setelah terkirim data akan dikunci, lanjutkan?')"><span class="fas fa-paper-plane"></span></a>
                      <?php else: ?>
                        <a href="#" class="btn btn-xs btn-link text-success" title="Surat Jalan Telah di Kirim"><span class="fas fa-check"></span></a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </div>
    
  </section>
  

  <div class="modal fade" id="modal-hapus">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-danger">
          <h4 class="modal-title">Peringatan</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center text=danger">
          <h3>Apakah anda yakin ingin menghapus Surat Jalan <u><strong>SJ001</strong></u> ?</h3>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <button type="button" class="btn btn-danger">YA! Hapus Data</button>
        </div>
      </div>
      
    </div>
    
  </div>
  

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
      "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
  $(function(){

      const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
      });

      <?php if($message = Session::get('success')): ?>
      Toast.fire({
          icon: 'success',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      Toast.fire({
          icon: 'warning',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      Toast.fire({
          icon: 'error',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/operasional/cabang/v_sj.blade.php ENDPATH**/ ?>