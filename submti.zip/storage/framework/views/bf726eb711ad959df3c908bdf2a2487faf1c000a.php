<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>NERACA</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
</head>
<body>
  <div class="container">
    <h1 class="mb-5">NERACA</h1>
    <div class="row">
      <label>AKTIVA</label>
      <table class="table mb-5 text-nowrap" width="100%">
        <thead>
          <tr>
            <th width="150px">Kode Akun</th>
            <th width="150px">Nama Akun</th>
            <th width="150px">Saldo</th>
          </tr>
        </thead>
        <tbody>

        <?php $ta = 0; $bukubesar = 0; ?>

        <?php $__currentLoopData = $trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php if($r->akun->kode_akun >= 999 && $r->akun->kode_akun <= 1999 && $r->akun->kelompok == "NERACA"): ?>
          
          <?php $__currentLoopData = $transaksi->where('kode_akun',$r->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
              $bukubesar  = $r->where('kode_akun',$k->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('debet') - $r->where('kode_akun',$k->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('kredit');
            ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $ta += $bukubesar; ?>

          <tr>
            <td width="150px"><?php echo e($r->akun->kode_akun); ?></td>
            <td width="150px"><?php echo e($r->akun->nama_akun); ?></td>
            <td width="150px"><?php echo e(number_format($bukubesar,0,',','.')); ?></td>
          </tr>
          
          <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        <tfoot class="bg-danger">
          <tr>
            <th colspan="2">TOTAL AKTIVA</th>
            <td><?php echo e(number_format($ta,0,',','.')); ?></td>
          </tr>
        </tfoot>
      </table>

      <?php $debet = 0; $kredit = 0; ?>

      <?php $__currentLoopData = $trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($r->akun->kode_akun >= 6000 && $r->akun->kode_akun <= 6999 && $r->akun->kelompok == "LABA RUGI"): ?>
          <?php $__currentLoopData = $transaksi->where('kode_akun',$r->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $debet += $d->debet ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if($r->akun->kode_akun >= 4000 && $r->akun->kode_akun <= 5999 && $r->akun->kelompok == "LABA RUGI"): ?>
          <?php $__currentLoopData = $transaksi->where('kode_akun',$r->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $kredit += $k->kredit ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <label>PASIVA</label>
      <table class="table mb-5 text-nowrap" width="100%">
        <thead>
          <tr>
            <th width="150px">Kode Akun</th>
            <th width="150px">Nama Akun</th>
            <th width="150px">Saldo</th>
          </tr>
        </thead>
        <tbody>

        <?php $laba = $kredit - $debet; $tp = 0; $bukubesar2 = 0; ?>
        
        <?php $__currentLoopData = $trade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php if($r1->akun->kode_akun >= 2000 && $r1->akun->kode_akun <= 3999 && $r1->akun->kelompok == "NERACA"): ?>
          
          <?php $__currentLoopData = $transaksi->where('kode_akun',$r1->kode_akun)->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
              $bukubesar2  = $r1->where('kode_akun',$k->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('debet') - $r1->where('kode_akun',$k->kode_akun)->whereBetween('tanggal',[$dari,$ke])->sum('kredit') * -1;
            ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php $tp += $bukubesar2; ?>
      
          <tr>
            <td width="150px"><?php echo e($r1->akun->kode_akun); ?></td>
            <td width="150px"><?php echo e($r1->akun->nama_akun); ?></td>
            <td width="150px"><?php echo e(number_format($bukubesar2,0,',','.')); ?></td>
          </tr>

          <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td width="150px"></td>
            <td width="150px">SALDO LABA TAHUN BERJALAN</td>
            <td width="150px"><?php echo e(number_format($laba,0,',','.')); ?></td>
          </tr>
        </tbody>

        <tfoot class="bg-warning">
          <tr>
            <th colspan="2">TOTAL PASIVA</th>
            <td><?php echo e(number_format($tp + $laba,0,',','.')); ?></td>
          </tr>
        </tfoot>
      </table>

    </div>
  </div>

<!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>



<!-- DataTables -->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(function () {
          $("#example1").DataTable({
              "scrollX":true,
          });
          $('#example2').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": false,
            "ordering": false,
            "info": false,
            "autoWidth": false,
            "responsive": false,
          });
        });
      </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/akuntansi/neraca.blade.php ENDPATH**/ ?>