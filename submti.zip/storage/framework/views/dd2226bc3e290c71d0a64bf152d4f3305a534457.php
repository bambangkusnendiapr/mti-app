<?php $__env->startSection('dashboard', 'active'); ?>

<?php $__env->startSection('content'); ?>

<?php if (app('laratrust')->ability('owner,admin,lord','*')) : ?>


<section class="content-header">
   <div class="container-fluid">
     <div class="row mb-2">
       <div class="col-sm-6">
         <h1>Dashboard</h1>
       </div>
       <div class="col-sm-6">
         <ol class="breadcrumb float-sm-right">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active">Dashboard</li>
         </ol>
       </div>
     </div>
   </div>
 </section>

 
 <section class="content">

  
  <div class="row">
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-info">
        <div class="inner">
          <h3><?php echo e($kontrak->count()); ?></h3>
          <p>Kontrak</p>
        </div>
        <div class="icon">
          <i class="fas fa-file"></i>
        </div>
        <a href="<?php echo e(route('kontrak.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-success">
        <div class="inner">
          <h3><?php echo e($sj->count()); ?></h3>
          <p>Ritase</p>
        </div>
        <div class="icon">
          <i class="fas fa-paper-plane"></i>
        </div>
        <a href="<?php echo e(route('suratjalan.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    

    <?php $pendapatan2 = 0; $total2 = 0; ?>
    
    <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <?php $__currentLoopData = $invoice->where('kontrak_id',$k->kontrak_id)->where('invoice_status','!=',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
          foreach($r->detail as $i){
            $pendapatan2   = $i->reconcile->sum('reconcile_klien_total');
          }
          $total2 += $pendapatan2 - $r->payment->sum('payment_bayar');
        ?>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-warning">
        <div class="inner">
          <h3>Rp <?php echo e(number_format($total2 / 1000000,1,',','.')); ?> Juta</h3>
          <p>Account Receiveable</p>
        </div>
        <div class="icon">
          <i class="fas fa-dollar-sign"></i>
        </div>
        <a href="<?php echo e(route('invoice.index')); ?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    


    <?php
        $tap1 = 0; $lsisa1 = 0; $lbayar1 = 0; $count1 = 0;
    ?>

    <?php $__currentLoopData = $leasing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $count1    = $r->payment->count();
        $lbayar1   += $count1 * $r->kendaraan->kendaraan_angsuran;
        $lsisa1    += ( $r->kendaraan->kendaraan_jangka_sisa - $count1 ) * $r->kendaraan->kendaraan_angsuran;
      ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $jumlah1 = 0; $total1 = 0; $ap = 0; ?>
      <?php $__currentLoopData = $p1->ap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $jumlah1 += $ap1->payment->sum('payment_partner_jumlah');
          $total1  = $p1->ap->sum('purchasing_jumlah') - $jumlah1;
          $tap1    += $total1;
        ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php
      $ap = ($tap1 + $lsisa1) / 1000000;
    ?>

    <div class="col-lg-3 col-6">
      
      <div class="small-box bg-danger">
        <div class="inner">
          <h3>Rp <?php echo e(number_format((float)$ap,1,',','.')); ?> Juta</h3>
          <p>Account Payable</p>
        </div>
        <div class="icon">
          <i class="fas fa-money-check"></i>
        </div>
        <a href="#" class="small-box-footer">&nbsp;</a>
      </div>
    </div>
    
  </div>
  
  
  <div class="row">
    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Gross Profit</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Revenue</th>
              <th>Expense</th>
              <th>Gross Profit</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php $pendapatan = 0; $pengeluaran = 0; $total = 0; ?>
              
              <?php $__currentLoopData = $invoice->where('kontrak_id',$k->kontrak_id)->where('invoice_status',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                  foreach($r->detail as $i){
                    $pendapatan   = $i->reconcile->sum('reconcile_klien_total');
                    $pengeluaran  = $i->reconcile->sum('reconcile_mti_total'); 
                  }
                  $total = $total + ($pendapatan - $pengeluaran);
                ?>
              
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($pengeluaran,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    

    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Ritase</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Jumlah</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td><?php echo e($sj->where('kontrak_id',$k->kontrak_id)->count()); ?></td>
              </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    
  </div>
  

  <div class="row">
    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Account Receiveable</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Kode Invoice</th>
              <th>Total Belum Bayar</th>
              <th>Usia Invoice</th>
            </tr>
            </thead>
            <tbody>
            
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <?php $pendapatan = 0; $pengeluaran = 0; $total = 0; ?>
              
              <?php $__currentLoopData = $invoice->where('kontrak_id',$k->kontrak_id)->where('invoice_status','!=',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                  foreach($r->detail as $i){
                    $pendapatan   = $i->reconcile->sum('reconcile_klien_total');
                  }
                ?>
              
              <tr>
                <td><?php echo e($k->kontrak_kode); ?></td>
                <td><?php echo e($r->invoice_kode); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan - $r->payment->sum('payment_bayar'),0,',','.')); ?></td>
                <td><?php echo e(\Carbon\Carbon::createFromDate($r->invoice_tanggal)->diffForHumans()); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
    

    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Account Payable</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Patner</th>
              <th>Jumlah Bayar</th>
              <th>Total Belum Bayar</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $tap = 0; $lsisa = 0; $lbayar = 0; $count = 0;
            ?>

            <?php $__currentLoopData = $leasing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $count    = $r->payment->count();
                $lbayar   += $count * $r->kendaraan->kendaraan_angsuran;
                $lsisa    += ( $r->kendaraan->kendaraan_jangka_sisa - $count ) * $r->kendaraan->kendaraan_angsuran;
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td>Leasing</td>
                <td>Rp <?php echo e(number_format($lbayar,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($lsisa,0,',','.')); ?></td>
              </tr>

            <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $jumlah = 0; $total = 0; ?>
              <?php $__currentLoopData = $p->ap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $jumlah += $ap->payment->sum('payment_partner_jumlah');
                  $total  = $p->ap->sum('purchasing_jumlah') - $jumlah;
                  $tap    += $total;
                ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($p->partner_nama); ?></td>
                <td>Rp <?php echo e(number_format($jumlah,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="3"><strong>Total AP : </strong>Rp <?php echo e(number_format($tap + $lsisa,0,',','.')); ?></td>
              </tr>
            </tfoot>
          </table>
        </div>
        
      </div>
      
    </div>
    
  </div>
  

  <div class="row">
    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Laporan Surat Jalan</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Kontrak</th>
              <th>Surat Jalan Terbit</th>
              <th>Surat Jalan Reconcile</th>
              <th>Surat Jalan Belum Kembali</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($r->kontrak_kode); ?></td>
                <td><?php echo e($sj->where('kontrak_id',$k->kontrak_id)->count()); ?></td>
                <td><?php echo e($sj->where('kontrak_id',$k->kontrak_id)->where('surat_jalan_status','3')->count()); ?></td>
                <td><?php echo e($sj->where('kontrak_id',$k->kontrak_id)->where('surat_jalan_status','!=','3')->count()); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>

    
    <div class="col-6">
      
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Laporan Gross Profit by Armada</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
          </div>
        </div>
        <div class="card-body table-responsive">
          <table class="table table-striped table-valign-middle text-nowrap">
            <thead>
            <tr>
              <th>Armada</th>
              <th>Revenue</th>
              <th>Expense</th>
              <th>Cicilan + Biaya</th>
              <th>Gross Profit</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($kn->kendaraan_nopol); ?> - <?php echo e($kn->jenis->jenis_kendaraan_nama); ?></td>

                <?php $revenue = 0; $expense = 0; $gp = 0; ?>
                <?php $__currentLoopData = $budget->where('kendaraan_id',$kn->kendaraan_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $sj->where('budget_id',$b->budget_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sjk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $reconcile->where('surat_jalan_id',$sjk->surat_jalan_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php 
                        $revenue += $rc->reconcile_klien_total;
                        $expense += $rc->reconcile_mti_total;
                      ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <td>Rp <?php echo e(number_format($revenue,0,',','.')); ?></td>

                
                <td>Rp <?php echo e(number_format($expense,0,',','.')); ?></td>

                
                <?php
                  $cicilan  = $kn->kendaraan_angsuran;
                  $biaya    = $purchasing->where('kendaraan_id',$kn->kendaraan_id)->sum('purchasing_jumlah');
                  $totalcb  = $cicilan + $biaya;
                  $gp       = $revenue - ($expense + $totalcb);
                ?>
                <td>Rp <?php echo e(number_format($totalcb,0,',','.')); ?></td>

                
                <td>Rp <?php echo e(number_format($gp,0,',','.')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        
      </div>
      
    </div>
  </div>

 </section>
 

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  
  <script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>

  
  <script>
    $(function () {
      $("#example1").DataTable({
          "scrollX": true
      });
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": true,
        "info": true,
        "autoWidth": true,
        "responsive": false,

      });
    });
  </script>

<?php $__env->stopPush(); ?>

<?php endif; // app('laratrust')->ability ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\server dotapp\mti\submti\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>