<!DOCTYPE html>



<?php $__env->startSection('daftar', 'active'); ?>

<?php $__env->startSection('konten'); ?>


<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
        <div class="col-sm-6">
            <h1>Form Pendaftaran Panti Asuhan</h1>
        </div>
        </div>
    </div>
</section>




<section class="content">

<form method="POST" action="<?php echo e(route('panti.store')); ?>">
<?php echo csrf_field(); ?>

<div class="container-fluid">

<div class="row">
    <div class="col-md-6">
        
        <div class="card card-outline card-info">
            <div class="card-header">
                <h3 class="card-title">Email & Password</h3>
            </div>

            <div class="card-body">
                
                <div class="form-group">
                    <label for="email">Email*</label>
                    <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password">Password*</label>
                    <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password-confirm">Konfirmasi Password*</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                </div>

            </div>
            

        </div>
        
    </div>

    <div class="col-md-6">
        
        <div class="card card-outline card-danger">
            <div class="card-header">
                <h3 class="card-title">Data Panti</h3>
            </div>

            <div class="card-body">

                <div class="form-group">
                    <label for="panti">Nama Panti*</label>
                    <input id="panti" type="text" class="form-control<?php echo e($errors->has('panti') ? ' is-invalid' : ''); ?>" name="panti" value="<?php echo e(old('panti')); ?>" required>
                    <?php if($errors->has('panti')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('panti')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="ketua">Nama Ketua*</label>
                    <input id="ketua" type="text" class="form-control<?php echo e($errors->has('ketua') ? ' is-invalid' : ''); ?>" name="ketua" value="<?php echo e(old('ketua')); ?>" required>
                    <?php if($errors->has('ketua')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('ketua')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="kategori">Kategori Panti*</label>
                    <select name="kategori" id="kategori" class="form-control<?php echo e($errors->has('kategori') ? ' is-invalid' : ''); ?>" required>
                    <option disabled selected>Pilih Kategori</option>
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($r->kategori_id); ?>"><?php echo e($r->kategori_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('kategori')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('kategori')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

            </div>
            

        </div>
        
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        
        <div class="card card-outline card-info">
            <div class="card-header">
                <h3 class="card-title">Alamat Panti</h3>
            </div>

            <div class="card-body row">
                
                
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="provinsi">Provinsi*</label>
                        <select name="provinsi" id="provinsi" class="form-control<?php echo e($errors->has('provinsi') ? ' is-invalid' : ''); ?>" required>
                            <option disabled selected>Pilih Provinsi</option>
                            <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('provinsi')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('provinsi')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="kota">Kota / Kabupaten*</label>
                        <select name="kota" id="kota" class="form-control<?php echo e($errors->has('kota') ? ' is-invalid' : ''); ?>" required>
                            
                        </select>
                        <?php if($errors->has('kota')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('kota')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="kecamatan">Kecamatan*</label>
                        <select name="kecamatan" id="kecamatan" class="form-control<?php echo e($errors->has('kecamatan') ? ' is-invalid' : ''); ?>" required>
                            
                        </select>
                        <?php if($errors->has('kecamatan')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('kecamatan')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="kelurahan">Kelurahan / Desa*</label>
                        <select name="kelurahan" id="kelurahan" class="form-control<?php echo e($errors->has('kelurahan') ? ' is-invalid' : ''); ?>" required>
                            
                        </select>
                        <?php if($errors->has('kelurahan')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('kelurahan')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                </div>
                

                
                <div class="col-md-6">

                    <div class="form-group pb-2">
                        <label for="alamat">Alamat Panti*</label>
                        <textarea id="alamat" rows="4" type="text" class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" name="alamat" value="<?php echo e(old('alamat')); ?>" required></textarea>
                        <?php if($errors->has('alamat')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('alamat')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                    
                        <div class="col-md-6 form-group">
                            <label for="rt">RT*</label>
                            <input id="rt" type="text" class="form-control<?php echo e($errors->has('rt') ? ' is-invalid' : ''); ?>" name="rt" value="<?php echo e(old('rt')); ?>" required>
                            <?php if($errors->has('rt')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('rt')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                    
                        <div class="col-md-6 form-group">
                            <label for="rw">RW*</label>
                            <input id="rw" type="text" class="form-control<?php echo e($errors->has('rw') ? ' is-invalid' : ''); ?>" name="rw" value="<?php echo e(old('rw')); ?>" required>
                            <?php if($errors->has('rw')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('rw')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                    </div>

                    <div class="form-group">
                        <label for="kodepos">Kode Pos</label>
                        <input id="kodepos" type="text" class="form-control<?php echo e($errors->has('kodepos') ? ' is-invalid' : ''); ?>" name="kodepos" value="<?php echo e(old('kodepos')); ?>">
                        <?php if($errors->has('kodepos')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('kodepos')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                </div>
                

            </div>
            

        </div>
        
    </div>
</div>


<div class="row">
    <div class="col-md-12">
        
        <div class="card card-outline card-danger">
            <div class="card-header">
                <h3 class="card-title">Kebutuhan Pendaftaran</h3>
            </div>

            <div class="card-body row">
                
                
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="telp">No. Telpon*</label>
                        <input id="telp" type="text" class="form-control<?php echo e($errors->has('telp') ? ' is-invalid' : ''); ?>" name="telp" value="<?php echo e(old('telp')); ?>" required>
                        <?php if($errors->has('telp')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('telp')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <label for="npwp">NPWP</label>
                        <input id="npwp" type="text" class="form-control<?php echo e($errors->has('npwp') ? ' is-invalid' : ''); ?>" name="npwp" value="<?php echo e(old('npwp')); ?>">
                        <?php if($errors->has('npwp')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('npwp')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                </div>
                

                
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="izin">No. Izin Operasional*</label>
                        <input id="izin" type="text" class="form-control<?php echo e($errors->has('izin') ? ' is-invalid' : ''); ?>" name="izin" value="<?php echo e(old('izin')); ?>" required>
                        <?php if($errors->has('izin')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('izin')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>

                    <div class="form-group py-4">
                        <button name="btn" type="submit" class="col-md-4 btn btn-primary text-center">
                            DAFTAR
                        </button>
                    </div>

                </div>
                

            </div>
            

        </div>
        
    </div>
</div>


</div>


</form>

</section>





    <?php $__env->startPush('scripts'); ?>
        
        <script src="<?php echo e(asset('plugins/select/js/select2.min.js')); ?>"></script>
        <script>
            $('select').each(function () {
                $(this).select2({
                theme: 'bootstrap4',
                width: 'style',
                placeholder: $(this).attr('placeholder'),
                allowClear: Boolean($(this).data('allow-clear')),
                });
            });
        </script>

        
        <script>
        $(document).ready(function(){
            
            $('#provinsi').on('change', function(e){
            var id = e.target.value;
            $.get('<?php echo e(url('/provinces/get')); ?>/'+id, function(data){
                $('#kota').empty();
                $('#kota').append('<option disabled selected>Pilih Kota</option>');
                $('#kecamatan').empty();
                $('#kelurahan').empty();
                $.each(data, function(index, val){
                $('#kota').append('<option value='+val.id+'>'+val.name+'</option>');
                });
            });
            });

            $('#kota').on('change', function(e){
            var id = e.target.value;
            $.get('<?php echo e(url('/cities/get')); ?>/'+id, function(data){
                $('#kecamatan').empty();
                $('#kecamatan').append('<option disabled selected>Pilih Kecamatan</option>');
                $('#kelurahan').empty();
                $.each(data, function(index, val){
                $('#kecamatan').append('<option value='+val.id+'>'+val.name+'</option>');
                });
            });
            });

            $('#kecamatan').on('change', function(e){
            var id = e.target.value;
            $.get('<?php echo e(url('/districts/get')); ?>/'+id, function(data){
                $('#kelurahan').empty();
                $('#kelurahan').append('<option disabled selected>Pilih Kelurahan</option>');
                $.each(data, function(index, val){
                $('#kelurahan').append('<option value='+val.id+'>'+val.name+'</option>');
                });
            });
            });

        });
        </script>

    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('css'); ?>
        
        <link href="<?php echo e(asset('plugins/select/css/select2.min.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('plugins/select/css/select2-bootstrap4.css')); ?>" rel="stylesheet" />
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/auth/register.blade.php ENDPATH**/ ?>