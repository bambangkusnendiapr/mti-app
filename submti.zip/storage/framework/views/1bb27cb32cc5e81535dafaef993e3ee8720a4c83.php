<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan AP</title>

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
</head>
<body class="text-xs">

  <div class="container">
    <div class="card">
      <div class="card-header">
        Laporan tertanggal : <?php echo e(\Carbon\Carbon::parse($dari)->format('d F Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($ke)->format('d F Y')); ?>

      </div>
      <div class="card-body">
        <h3 class="text-center">Laporan Account Payable</h3>
        <table class="table table-striped table-valign-middle text-nowrap">
          <thead>
          <tr>
            <th>Patner</th>
            <th>Jumlah Bayar</th>
            <th>Total Belum Bayar</th>
          </tr>
          </thead>
          <tbody>
          <?php
              $tap = 0; $lsisa = 0; $lbayar = 0; $count = 0;
          ?>

          <?php $__currentLoopData = $leasing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $count    = $r->payment->whereBetween('created_at',[$dari,$ke])->count();
              $lbayar   += $count * $r->kendaraan->kendaraan_angsuran;
              $lsisa    += ( $r->kendaraan->kendaraan_jangka_sisa - $count ) * $r->kendaraan->kendaraan_angsuran;
            ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <td>Leasing</td>
              <td>Rp <?php echo e(number_format($lbayar,0,',','.')); ?></td>
              <td>Rp <?php echo e(number_format($lsisa,0,',','.')); ?></td>
            </tr>

          <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $jumlah = 0; $total = 0; ?>
            <?php $__currentLoopData = $p->ap->whereBetween('created_at',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $jumlah += $ap->payment->sum('payment_partner_jumlah');
                $total  = $p->ap->sum('purchasing_jumlah') - $jumlah;
                $tap    += $total;
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($p->partner_nama); ?></td>
              <td>Rp <?php echo e(number_format($jumlah,0,',','.')); ?></td>
              <td>Rp <?php echo e(number_format($total,0,',','.')); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="3"><strong>Total AP : </strong>Rp <?php echo e(number_format($tap + $lsisa,0,',','.')); ?></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>  
  </div>

</body>

<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
</html><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/laporan/laporan_ap_cetak.blade.php ENDPATH**/ ?>