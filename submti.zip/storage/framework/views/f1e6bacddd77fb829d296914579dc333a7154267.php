<?php $__env->startSection('menu-op','menu-open'); ?>

<?php $__env->startSection('op','active'); ?>

<?php $__env->startSection('po','active'); ?>

<?php $__env->startSection('content'); ?>

  
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6 mb-2">
          <h1>Budgeting</h1>
        </div>
        <div class="col-sm-6">
          <a href="<?php echo e(route('budget.create',$po->po_id)); ?>" class="btn btn-primary btn-sm float-right"><span class="fa fa-plus">&nbsp;</span>Tambah Budgeting</a>

        </div>
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="#">Operasional</a></li>
            <li class="breadcrumb-item">Manage PO</li>
            <li class="breadcrumb-item active">Budgeting</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="container-fluid">

        <div class="col-12">
          <div class="card">

            <div class="card-body">


              <table id="example1" class="table table-striped text-nowrap" cellspacing="0" width="100%">
                <thead>
                <tr>
                  <th width="25px">No</th>
                  <th>Jenis Kendaraan</th>
                  <th>Nopol</th>
                  <th>Driver</th>
                  <th>Store</th>
                  <th>Koreksi</th>
                  <th>Total Standar</th>
                  <th>Total MDI</th>
                  <th>Total Koreksi</th>
                  <th>Ajukan</th>
                  <th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                if($b->budget_mdi == null){
                  $mdi          = 0;
                  $jstore       = $b->bstore->count();
                  $mdi_tambahan = $jstore - $b->po->po_mdi_ke;
                  
                  if($jstore >= $b->po->po_mdi_ke){
                    $mdi = $b->po->po_mdi_dasar + ($mdi_tambahan * $b->po->po_mdi_tambahan);
                  }

                }else{
                  $mdi = $b->budget_mdi;
                }
                ?>
                <tr>
                  <td class="text-right" width="25px"><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($b->jenis->jenis_kendaraan_nama); ?></td>
                  <td><?php echo e($b->kendaraan->kendaraan_nopol); ?></td>
                  <td><?php echo e($b->driver->driver_nama); ?></td>
                  <td class="text-center">
                    <?php if($b->budget_status != 1): ?>
                      <a href="#" data-target="#modal-store-view<?php echo e($b->budget_id); ?>" data-toggle="modal" class="btn btn-xs btn-link text-info"  title="View"><span class="fa fa-eye" ></span></a>
                      <a href="<?php echo e($b->budget_id); ?>" data-target="#modal-store-create" data-toggle="modal" class="btn btn-xs btn-link text-info create" data-value="<?php echo e($b->budget_id); ?>" title="Store"><span class="fa fa-plus" ></span></a>
                    <?php endif; ?>
                  </td>
                  <td class="text-center">
                    <?php if($b->budget_status != 1): ?>
                      <a href="<?php echo e(route('koreksipo.show',$b->budget_id)); ?>" data-target="" data-toggle="" class="btn btn-xs btn-link" title="Koreksi"><span class="fa fa-calculator"></span></a>
                    <?php endif; ?>
                  </td>
                  <td>Rp <?php echo e(number_format($b->bstore->max('budgetstore_mti_uang_jalan'),0,',','.')); ?></td>
                  <td>Rp <?php echo e(number_format($mdi,0,',','.')); ?></td>
                  <td>Rp <?php echo e(number_format($b->koreksi->sum('koreksi_po_uang_jalan'),0,',','.')); ?></td>
                  <td class="text-center">
                    <?php if($b->budget_status == null): ?>
                      <a href="#" data-target="#modal-md<?php echo e($b->budget_id); ?>" data-toggle="modal" class="btn btn-xs btn-link text-success"  title="View"><span class="fa fa-check"></span></a>
                    <?php endif; ?>
                  </td>
                  <td class="text-center">
                    <?php if($b->budget_status == null): ?>
                      <a href="<?php echo e(route('budget.edit',$b->budget_id)); ?>" class="btn btn-xs btn-link"  title="Edit"><span class="fa fa-edit" ></span></a>
                      <a href="#" data-target="#modal-hapus<?php echo e($b->budget_id); ?>" data-toggle="modal" class="btn btn-xs btn-link" title="Hapus"><span class="fa fa-trash"></span></a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </div>
    
  </section>
  

  <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-hapus<?php echo e($r->budget_id); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo e(route('budget.destroy',$r->budget_id)); ?>" method="post"></form>
        <div class="modal-header bg-danger">
          <h4 class="modal-title">Peringatan</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center text=danger">
          <h3>Apakah anda yakin ingin menghapus data Budget ?</h3>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-danger">YA! Hapus Data</button>
        </div>
      </div>
      
    </div>
    
  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div class="modal fade" id="modal-store-create">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h4 class="modal-title">Tambah Store</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('budgetstore.store')); ?>" method="post"> <?php echo csrf_field(); ?>
            <div class="form-group">
                
              <div class="row">
                <div class="form-group col-md-12">
                  <label for="store">Store Name</label>
                  <select id="store" class="form-control select2bs4 store" name="store">
                    <option disabled selected>-- Pilih Store --</option>
                    <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($s->store_id); ?>"><?php echo e($s->store_kode); ?> - <?php echo e($s->store_nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="row">

                <input type="hidden" name="budget_id" value="" id="budget_id" class="budget_id"/>

                <div class="col-md-6">
                  <div class="form-group" id="uang_jalan">
                    <input id="uang_jalan" class="form-control-plaintext uang_jalan" type="hidden" name="uang_jalan" value="" >
                  </div>
                </div>

                  <input class="form-control" type="hidden" name="tamkur" placeholder="" id="tamkur" value="">

              </div>
              
              <div class="form-group mt-2">
                <input type="submit" value="Simpan" class="btn btn-primary float-right">
                <input type="button" value="Batal" data-dismiss="modal" class="btn btn-danger float-left">
              </div>
              
            </form>

            </div>
        </div>
      </div>
      
    </div>
    
  </div>
  
  
  <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-store-view<?php echo e($b->budget_id); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h4 class="modal-title">List Store</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center p-0">
          <table class="table nowrap table-striped">

            <thead>
              <tr>
                <th style="width: 50px">No</th>
                <th>Kode Store</th>
                <th>Uang Jalan</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $b->bstore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td style="width: 50px"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($bs->store->store_nama); ?></td>
                <td>Rp <?php echo e(number_format($bs->budgetstore_mti_uang_jalan,0,',','.')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

          </table>
        </div>

      </div>
      
    </div>
    
  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="modal-md<?php echo e($b->budget_id); ?>">
    <div class="modal-dialog">
      <div class="modal-content">
        <form action="<?php echo e(route('budget.pengajuan',$b->budget_id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="modal-header bg-primary">
          <h4 class="modal-title">Uang Jalan dan Multidrop</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

          <div class="col-md-12">
            <label for="">Uang Jalan</label>
            <div class="form-group" id="buj">
              <?php if($b->budget_uang_jalan != null): ?>
                <input id="buj" class="form-control" type="text" value="Rp <?php echo e(number_format($b->budget_uang_jalan,0,',','.')); ?>" readonly/>
                <input id="buj" class="form-control" type="hidden" name="buj" value="<?php echo e($b->budget_uang_jalan); ?>" readonly/>
              <?php else: ?>
                <input id="buj" class="form-control" type="text" value="Rp <?php echo e(number_format($b->bstore->max('budgetstore_mti_uang_jalan'),0,',','.')); ?>" readonly/>
                <input id="buj" class="form-control" type="hidden" name="buj" value="<?php echo e($b->bstore->max('budgetstore_mti_uang_jalan')); ?>" readonly/>
              <?php endif; ?>
            </div>
          </div>

          <input id="kt" type="hidden" name="kt" value="<?php echo e($b->bstore->max('budgetstore_klien_tarif')); ?>" readonly>
          
          <?php
            if($b->budget_mdi == null){
            
              $mdi          = 0;
              $jstore       = $b->bstore->count();
              $mdi_tambahan = $jstore - $b->po->po_mdi_ke;
              
              if($jstore >= $b->po->po_mdi_ke){
                $mdi = $b->po->po_mdi_dasar + ($mdi_tambahan * $b->po->po_mdi_tambahan);
              }

            }else{
              $mdi = $b->budget_mdi;
            }

            if($b->budget_mdk == null){
            
              $mdk          = 0;
              $jstore       = $b->bstore->count();
              $mdk_tambahan = $jstore - $b->po->po_mdk_ke;
              
              if($jstore >= $b->po->po_mdk_ke){
                $mdk = $b->po->po_mdk_dasar + ($mdk_tambahan * $b->po->po_mdk_tambahan);
              }

            }else{
              $mdk = $b->budget_mdk;
            }

          ?>

          <input id="mdk" type="hidden" name="mdk" value="<?php echo e($mdk); ?>" readonly>

          <div class="col-md-12">
            <label for="">Multidrop</label>
            <div class="form-group" id="mdi">
              <input id="mdi" class="form-control" type="text" value="Rp <?php echo e(number_format($mdi,0,',','.')); ?>" readonly>
              <input id="mdi" class="form-control" type="hidden" name="mdi" value="<?php echo e($mdi); ?>" readonly>
            </div>
          </div>

          <div class="col-md-12">
            <label for="">Koreksi</label>
            <div class="form-group" id="mdi">
              <input id="mdi" class="form-control" type="text" name="koreksi" value="Rp <?php echo e(number_format($b->koreksi->sum('koreksi_po_uang_jalan'),0,',','.')); ?>" readonly>
            </div>
          </div>

          <div class="form-group mt-2 mb-5">
            <input type="submit" value="Ajukan" class="btn btn-primary float-right">
            <input type="button" value="Batal" data-dismiss="modal" class="btn btn-danger float-left">
          </div>

        </div>
        </form>
      </div>
      
    </div>
    
  </div>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  

<?php $__env->startPush('css'); ?>

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
  
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>

  
  <script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
  
  <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <script>
    $(function () {
      //Initialize Select2 Elements
      $('.select2').select2()
  
      //Initialize Select2 Elements
      $('.select2bs4').select2({
        theme: 'bootstrap4'
      })
    })
    </script>

  
  <script>

    $(function () {

      $("#example1").DataTable({
          "scrollX":true,

      });
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": true,
        "searching": true,
        "ordering": false,
        "info": true,
        "autoWidth": false,
        "responsive": true,
      });
    });

  </script>

  
  <script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
  <script>
    $(function(){

        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });

        <?php if($message = Session::get('success')): ?>
        Toast.fire({
            icon: 'success',
            title: '<?php echo e($message); ?>'
        })
        <?php endif; ?>

        <?php if($message = Session::get('warning')): ?>
        Toast.fire({
            icon: 'warning',
            title: '<?php echo e($message); ?>'
        })
        <?php endif; ?>

        <?php if(session('error')): ?>
        Toast.fire({
            icon: 'error',
            title: "<?php echo e(session('error')); ?>"
        })
        <?php endif; ?>

    });
  </script>

  <script>
    $(document).ready(function(){
        
      $('.create').on('click', function(){

        var id = $(this).attr("href");
        $('.budget_id').val('');
        $('.uang_jalan').val('');
        $('.budget_id').val(id);

        $('.store').on('change',function(e){
          var store = e.target.value;
          var id    = $(".budget_id").val();
      
          $.get('<?php echo e(url('/tarif/get/')); ?>/'+id+'/'+store, function(data){
            $('.budget_id').val(id);
            $('.uang_jalan').val(data.tarif_mti_uang_jalan);
          });

        });
        
      });

    });
  </script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\Aplikasi\server dotapp\mti\submti\resources\views/admin/operasional/cabang/v_budget.blade.php ENDPATH**/ ?>