<?php $__env->startSection('menu-keuangan','menu-open'); ?>

<?php $__env->startSection('keuangan','active'); ?>

<?php $__env->startSection('reconcile','active'); ?>

<?php $__env->startSection('content'); ?>

  
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6 mb-2">
          <h1>Manage Surat Jalan</h1>
        </div>
        <div class="col-sm-12">
          <ol class="breadcrumb float-sm-left">
              <li class="breadcrumb-item"><a href="#">Keuangan</a></li>
            <li class="breadcrumb-item active">Manage Surat Jalan</li>
          </ol>
        </div>
      </div>
    </div>
  </section>

  
  <section class="content">
    <div class="container-fluid">
      <div class="row">

        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <table id="example1" class="table table-striped" width="100%" cellspacing="0">
                <thead>
                <tr>
                  <th>No</th>
                  <th>KD PO</th>
                  <th>Jenis Kendaraan</th>
                  <th>Tarif</th>
                  <th>MDK</th>
                  <th>Additional</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $sj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="text-right"><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($r->budget->po->po_kode); ?></td>
                  <td><?php echo e($r->budget->jenis->jenis_kendaraan_nama); ?></td>
                  <td>
                    <?php if($r->reconcile != null): ?>
                      <s class="text-danger">Rp <?php echo e(number_format($r->surat_jalan_tarif,0,',','.')); ?></s> 
                      <span class="text-success">Rp <?php echo e(number_format($r->reconcile->reconcile_tarif,0,',','.')); ?></span>
                    <?php else: ?>
                      Rp <?php echo e(number_format($r->surat_jalan_tarif,0,',','.')); ?>

                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($r->reconcile != null): ?>
                      <s class="text-danger">Rp <?php echo e(number_format($r->surat_jalan_mdk,0,',','.')); ?></s> 
                      <span class="text-success">Rp <?php echo e(number_format($r->reconcile->reconcile_mdk,0,',','.')); ?></span>
                    <?php else: ?>
                      Rp <?php echo e(number_format($r->surat_jalan_mdk,0,',','.')); ?>

                    <?php endif; ?>  
                  </td>
                  <td>
                    <?php if($r->reconcile != null): ?>
                      <span class="text-success">Rp <?php echo e(number_format($r->reconcile->reconcile_add,0,',','.')); ?></span>
                    <?php endif; ?>
                  </td>
                  <td class="row text-right">
                    <div class="btn-group">
                      <?php if($r->surat_jalan_status == 1): ?>
                        <a href="<?php echo e(route('suratjalan.terima',$r->surat_jalan_id)); ?>" class="btn btn-xs btn-link text-primary" title="Terima Surat Jalan"><span class="fas fa-hands"></span></a>
                      <?php elseif($r->surat_jalan_status == 2): ?>
                        <a href="#" data-target="#sj-edit<?php echo e($r->surat_jalan_id); ?>" data-toggle="modal" class="btn btn-xs btn-link text-primary" title="Terima Surat Jalan"><span class="fas fa-file"></span> Reconcile</a>
                      <?php else: ?>
                        <a href="#" class="btn btn-xs btn-link text-success" title="Selesai di Reconcile"><span class="fas fa-check"></span> Selesai</a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </div>
    
  </section>
  

  <?php $__currentLoopData = $sj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="sj-edit<?php echo e($r->surat_jalan_id); ?>">
      <div class="modal-dialog">
        <div class="modal-content">
        <form action="<?php echo e(route('suratjalan.update',$r->surat_jalan_id)); ?>" method="POST">
          <div class="modal-header bg-info">
            <h4 class="modal-title">Edit Surat Jalan</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
              <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
              <div class="form-group">
                <label for="tarif">Tarif</label>
                <input type="text" id="tarif" class="form-control uang" name="tarif" value="<?php echo e($r->surat_jalan_tarif); ?>">
              </div>
              <div class="form-group">
                <label for="mdk">Multidrop Klien</label>
                <input type="text" id="mdk" class="form-control uang" name="mdk" value="<?php echo e($r->surat_jalan_mdk); ?>" required>
              </div>
              <div class="form-group">
                <label for="add">Additional</label>
                <input type="text" id="add" class="form-control uang" name="add" value="<?php echo e($r->driver_add); ?>">
              </div>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-success">Update</button>
          </div>
        </form>
        </div>
        
      </div>
      
    </div>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
      "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
  $(function(){

      const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
      });

      <?php if($message = Session::get('success')): ?>
      Toast.fire({
          icon: 'success',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      Toast.fire({
          icon: 'warning',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      Toast.fire({
          icon: 'error',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

  });
</script>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.date').mask('00/00/0000');
    $('.uang').mask('000.000.000.000', {reverse: true});
    $('.time').mask('00:00:00');
    $('.date_time').mask('00/00/0000 00:00:00');
  });
</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/keuangan/v_sj.blade.php ENDPATH**/ ?>