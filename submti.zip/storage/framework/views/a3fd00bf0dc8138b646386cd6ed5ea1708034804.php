<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Buku Besar</title>

     <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  <style>
    @media  print {
    .pagebreak { page-break-before: always; } /* page-break-after works, as well */
    }
  </style>
</head>
<body>
    <div class="container">
        <h1 class="">Buku Besar</h1>
        <div class="card">
            <div class="card-body">
            <?php $__currentLoopData = $kode_akun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $jdebet = 0; $jkredit = 0; ?>
            <label><?php echo e($ka->kode_akun); ?> | <?php echo e($ka->nama_akun); ?></label>
            <table class="table mb-5 text-nowrap" width="100%">
                <thead>
                    <tr>
                        <td width="150px">Tanggal</td>
                        <td width="500px">Uraian</td>
                        <td width="150px">Debet</td>
                        <td width="150px">Kredit</td>
                    </tr>
                    <tr>
                        <th colspan="2">Saldo Awal</th>
                            <?php

                            if($ka->normal == "DEBET"){
                                $awaldebet = $ka->saldo_awal;
                                $awalkredit = 0;
                            }else{
                                $awaldebet = 0;
                                $awalkredit = $ka->saldo_awal;
                            }
                            ?>
                            <td><?php echo e(number_format($awaldebet,0,',','.')); ?></td>
                            <td><?php echo e(number_format($awalkredit,0,',','.')); ?></td>
                    </tr>
                </thead>
                    <?php $__currentLoopData = $ka->transaksi->whereBetween('tanggal',[$dari,$ke]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tbody>
                        <tr>
                            <td><?php echo e($t->posting->tanggal); ?></td>
                            <td><?php echo e($t->posting->uraian); ?></td>
                            <td><?php echo e(number_format($t->debet,0,',','.')); ?></td>
                            <td><?php echo e(number_format($t->kredit,0,',','.')); ?></td>
                        </tr>
                    </tbody>
                        <?php
                            $jdebet = $t->debet + $jdebet;
                            $jkredit = $t->kredit + $jkredit;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $jdebet = $jdebet + $awaldebet;
                            $jkredit = $jkredit + $awalkredit;

                            if($jdebet >= $jkredit){
                                $akhirdebet = $jdebet - $jkredit; $akhirkredit = 0;
                            }else{
                                $akhirdebet = 0; $akhirkredit = $jkredit - $jdebet;
                            }

                        ?>

                    <tfoot>
                        <tr>
                            <th>JUMLAH</th>
                            <td>&nbsp;</td>
                            <td><?php echo e(number_format($jdebet,0,',','.')); ?></td>
                            <td><?php echo e(number_format($jkredit,0,',','.')); ?></td>
                        </tr>
                        <tr>
                            <th>SALDO AKHIR</th>
                            <td>&nbsp;</td>
                            <td><?php echo e(number_format($akhirdebet,0,',','.')); ?></td>
                            <td><?php echo e(number_format($akhirkredit,0,',','.')); ?></td>
                        </tr>
                    </tfoot>
            </table>
            <div class="pagebreak"> </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        </div>
        
    </div>



<!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>



<!-- DataTables -->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(function () {
          $("#example1").DataTable({
              "scrollX":true,
          });
          $('#example2').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": false,
            "ordering": false,
            "info": false,
            "autoWidth": false,
            "responsive": false,
          });
        });
      </script>
</body>
</html>
<?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/akuntansi/buku_besar.blade.php ENDPATH**/ ?>