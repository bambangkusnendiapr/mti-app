<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>v</b> 1.0.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y') - 1); ?> - <?php echo e(date('Y')); ?> <a href="http://dot.biz.id/">Dunia Optima Teknologi</a>.</strong> All rights
    reserved.
</footer>
<?php /**PATH C:\Users\ASUS\Documents\Aplikasi\server dotapp\mti\submti\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>