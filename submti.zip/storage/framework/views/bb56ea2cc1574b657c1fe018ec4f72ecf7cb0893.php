<?php $__env->startSection('laporan-open','menu-open'); ?>

<?php $__env->startSection('laporan-active','active'); ?>

<?php $__env->startSection('laporan-omset','active'); ?>

<?php $__env->startSection('content'); ?>

  
  <section class="content-header">
    <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Laporan Omset</h1>
      </div>
      <div class="col-sm-12">
        <ol class="breadcrumb float-sm-left">
          <li class="breadcrumb-item"><a href="#">Laporan</a></li>
          <li class="breadcrumb-item active">Laporan Omset</li>
        </ol>
      </div>
    </div>
    </div>
  </section>

    
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                Laporan Omset
              </div>
              <div class="card-body">
                <form action="<?php echo e(route('laporan.omset.cetak')); ?>" method="post" target="_blank"><?php echo csrf_field(); ?>

                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <label for="dari">Dari</label>
                        <input id="dari" class="form-control" type="date" name="dari">
                      </div>
                    </div>
                    <div class="col-6">
                      <div class="form-group">
                        <label for="ke">Ke</label>
                        <input id="ke" class="form-control" type="date" name="ke">
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-6">
                      <div class="form-group">
                        <button class="btn btn-primary" type="submit">Cetak</button>
                      </div>
                    </div>
                  </div>

                </form>
              </div>
            </div>
          </div>
          
        </div>
        
      </div>
      
    </section>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/laporan/laporan_omset.blade.php ENDPATH**/ ?>