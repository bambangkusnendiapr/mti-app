<?php $__env->startSection('menu-keuangan','menu-open'); ?>

<?php $__env->startSection('keuangan','active'); ?>

<?php $__env->startSection('invoice','active'); ?>

<?php $__env->startSection('content'); ?>

    
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6 mb-2">
            <h1>Manage Invoice</h1>
          </div>
          <div class="col-sm-6">
            <a href="<?php echo e(route('invoice.create')); ?>" class="btn btn-primary btn-sm float-right"><span class="fa fa-plus">&nbsp;</span>Tambah Invoice</a>

          </div>
         <div class="col-sm-12">
            <ol class="breadcrumb float-sm-left">
                <li class="breadcrumb-item"><a href="#">Keuangan</a></li>
              <li class="breadcrumb-item active">Manage Invoice</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    
    <section class="content">
      <div class="container-fluid">
        <div class="row">

          <div class="col-12">
            <div class="card">
              
              
              <div class="card-body">
                <table id="example1" class="table table-striped text-nowrap" cellspacing="0" width="100%">
                  <thead>
                  <tr>
                    <th>No</th>
                    <th>Kode Invoice</th>
                    <th>Tanggal Invoice</th>
                    <th>Detail</th>
                    <th></th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-right"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($r->invoice_kode); ?></td>
                    <td><?php echo e($r->invoice_tanggal); ?></td>
                    <td class="text-center">
                      <a href="<?php echo e(route('invoice.show',$r->invoice_id)); ?>" class="btn btn-xs btn-link text-info" title="Detail Invoice"><span class="fa fa-copy" ></span></a>
                    </td>
                    <td class="text-center">
                      <a href="<?php echo e(route('invoice.cetak',$r->invoice_id)); ?>" class="btn btn-xs btn-link text-success" target="_blank" title="Print"><span class="fa fa-print" ></span></a>
                      <a href="<?php echo e(route('invoice.edit',$r->invoice_id)); ?>" class="btn btn-xs btn-link text-warning"  title="Edit"><span class="fa fa-edit" ></span></a>
                      <a href="#" data-target="#modal-hapus<?php echo e($r->invoice_id); ?>" data-toggle="modal" class="btn btn-xs btn-link text-danger" title="Hapus"><span class="fa fa-trash"></span></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              
            </div>
            
          </div>
          
        </div>
        
      </div>
      
    </section>
    
  
  <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="modal-hapus<?php echo e($r->invoice_id); ?>">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="<?php echo e(route('invoice.destroy',$r->invoice_id)); ?>" method="post"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
          <div class="modal-header bg-danger">
            <h4 class="modal-title">Peringatan</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body text-center text=danger">
            <h3>Apakah anda yakin ingin menghapus Invoice dengan kode kontrak<u><strong><?php echo e($r->kontrak->kontrak_kode); ?></strong></u> ?</h3>
          </div>
          <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-danger">YA! Hapus Data</button>
          </div>
          </form>
        </div>
        
      </div>
      
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('css'); ?>
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>


<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


<script>
  $(function () {
    $("#example1").DataTable({
        "scrollX":true,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": false,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script>
  $(function(){

      const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000
      });

      <?php if($message = Session::get('success')): ?>
      Toast.fire({
          icon: 'success',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('warning')): ?>
      Toast.fire({
          icon: 'warning',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

      <?php if($message = Session::get('error')): ?>
      Toast.fire({
          icon: 'error',
          title: '<?php echo e($message); ?>'
      })
      <?php endif; ?>

  });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/keuangan/v_invoice.blade.php ENDPATH**/ ?>