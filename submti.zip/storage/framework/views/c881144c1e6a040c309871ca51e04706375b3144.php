<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Surat Jalan</title>

    
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
</head>
<body>
    <div class="container">
      <div class="row mb-2">
        <div class="col-md-3">
          <img class="img-fluid float-left" width="250px" src="<?php echo e(asset('admin/dist/img/AdminLTELogo.png')); ?>" alt="">
        </div>
        <div class="col-md-9 mt-4 text-sm">
          <h2><strong>PT MARCOS TRANS INDONESIA</strong></h2>

          <small>Office  : Komplek Kranggan Permai Jl.Wijaya Kusuma Bs. 6 No. 13 jatisampurna, Bekasi</small><br>
          <small>Workshop: Jl Gemalapik No. 11 Pasir Sari Cikarang Selatan Bekasi</small><br>
          <small>Telp    : (021) 2867491 - 89532043 Fax. (021) 84992430 Website : www.marcostrans.com</small><br>
          <small>E-mail  : office@marcostrans.com/trans.marcos@yahoo.co.id</small><br>
        </div>
      </div>

      <div class="card border border-dark">
        <div class="row">
          <div class="col-md-12 mt-2">
            <h2 class="text-center"><strong>SURAT JALAN</strong></h2>
          </div>
        </div>
        <div class="card-body  ">

          <div class="row">
            <div class="col-md-6">
              <label for="">No.SJ</label>
              <p for=""><?php echo e($sj->surat_jalan_id); ?></p>
            </div>
            <div class="col-md-6 text-right">
              <label for="">Jenis Kendaraan</label>
              <p for=""><?php echo e($sj->budget->jenis->jenis_kendaraan_nama); ?></p>
            </div>
          </div>

          <div class="row">
            <div class="col-md-3">
              <label for="">No Polisi</label>
              <p><?php echo e($sj->budget->kendaraan->kendaraan_nopol); ?></p>
            </div>
            <div class="col-md-4">
              <label for="">Pengirim</label>
              <p><?php echo e(\Auth::user()->name); ?></p>
            </div>
            <div class="col-md-5">
              <label for="">Penerima</label>
              <p>
                <?php $__currentLoopData = $sj->budget->bstore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($r->store->store_kode); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </p>
            </div>
          </div>

          <div class="row">
            <div class="col-md-3">
              <label for="">Driver</label>
              <p><?php echo e($sj->budget->driver->driver_nama); ?></p>
            </div>
            <div class="col-md-9">
              <table class="table table-bordered table-striped" id="example2" width="100%" cellspacing="0">
                <thead class="thead-dark">
                  <tr>
                    <th class="text-center" width="100px">Banyaknya</th>
                    <th class="text-center" width="250px">Nama Barang</th>
                    <th width="50px">Berat KG</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sj->barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($b->sj_barang_banyak); ?></td>
                  <td><?php echo e($b->sj_barang_nama); ?></td>
                  <td><?php echo e($b->sj_barang_berat); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                </tr>
                <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="row">
            <div class="col-md-3 text-center">

            </div>
            <div class="col-md-3 text-center">
              <label for="">Pengirim</label>
              <p></p>
              <p>________________</p>
            </div>
            <div class="col-md-3 text-center">
              <label for="">Penerima</label>
              <p></p>
              <p>________________</p>
            </div>
            <div class="col-md-3 text-right">
              <label for="">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;, <?php echo e(\Carbon\Carbon::parse($sj->budget->created_at)->format('d/m/Y')); ?></label>
            </div>
          </div>
        </div>
      </div>

    </div>




<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/demo.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>




<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>


    <script>
        $(function () {
          $("#example1").DataTable({
              "scrollX":true,
          });
          $('#example2').DataTable({
            "paging": false,
            "lengthChange": false,
            "searching": false,
            "ordering": false,
            "info": false,
            "autoWidth": false,
            "responsive": false,
          });
        });
      </script>
</body>
</html>
<?php /**PATH /home/dota2913/public_html/submti/resources/views/admin/operasional/cabang/l_sj.blade.php ENDPATH**/ ?>