<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Laporan Omset</title>

  
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>">
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
</head>
<body class="text-xs">

  <div class="container">
    <div class="card">
      <div class="card-header">
        Laporan tertanggal : <?php echo e(\Carbon\Carbon::parse($dari)->format('d F Y')); ?> s/d <?php echo e(\Carbon\Carbon::parse($ke)->format('d F Y')); ?>

      </div>
      <div class="card-body">
        <hr>
        <?php $__currentLoopData = $kontrak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
            <div class="col-6">
              <h3><?php echo e($k->kontrak_kode); ?></h3>
            </div>
          </div>
          <table class="table table-striped table-borderless text-nowrap">
            <thead class="thead-dark">
              <tr>
                <th>No</th>
                <th>Invoice Kode</th>
                <th>Pendapatan</th>
                <th>Pengeluaran</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $k->invoice->whereBetween('created_at',[$dari,$ke])->where('invoice_status',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $pendapatan = 0; $pengeluaran = 0; $total = 0;
                foreach($r->detail as $i){
                  $pendapatan   = $i->reconcile->sum('reconcile_klien_total');
                  $pengeluaran  = $i->reconcile->sum('reconcile_mti_total'); 
                }
              ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($r->invoice_kode); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($pengeluaran,0,',','.')); ?></td>
                <td>Rp <?php echo e(number_format($pendapatan - $pengeluaran,0,',','.')); ?></td>
              </tr>
              <?php
                $total = $total + ($pendapatan - $pengeluaran);
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <th>Rp <?php echo e(number_format($total,0,',','.')); ?></th>
              </tr>
            </tfoot>
          </table>
          <div class="row">
            <div class="col-12">
              <strong>Jumlah Ritase :</strong> <?php echo e($k->sj->count()); ?>

            </div>
          </div>
          <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>  
  </div>

</body>

<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
</html><?php /**PATH C:\xampp\htdocs\MTI\resources\views/admin/laporan/laporan_omset_cetak.blade.php ENDPATH**/ ?>