<header>
<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- SEARCH FORM -->
    
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">


        <li class="nav-item dropdown user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
              <span class="d-none d-md-inline mr-2"><?php echo e(\Auth::user()->name); ?></span>
              <img src="<?php echo e(asset('images/')); ?>/<?php echo e(\Auth::user()->image); ?>" class="user-image img-circle elevation-2" alt="User Image">
          </a>
          <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <!-- User image -->
            <li class="user-header bg-dark">
              <img src="<?php echo e(asset('images/')); ?>/<?php echo e(\Auth::user()->image); ?>" class="img-circle elevation-2" alt="User Image">

              <p>
                <?php echo e(\Auth::user()->name); ?>

              </p>
            </li>
            <!-- Menu Body -->

            <!-- Menu Footer-->
            <li class="user-footer">
              <a href="/profile" class="btn btn-default btn-flat"><span class="fas fa-user"></span> Profile</a>
              <a href="/logout" class="btn btn-default btn-flat float-right"><span class="fas fa-sign-out-alt"></span> Sign out</a>
            </li>
          </ul>
        </li>
        
      </ul>
  </nav>
  <!-- /.navbar -->
</header>
<?php /**PATH C:\Users\ASUS\Documents\Aplikasi\server dotapp\mti\submti\resources\views/layouts/admin/header.blade.php ENDPATH**/ ?>