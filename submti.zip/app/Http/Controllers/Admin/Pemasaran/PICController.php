<?php

namespace App\Http\Controllers\Admin\Pemasaran;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Pemasaran\PIC;
use Session;

class PICController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $pic = new PIC;
        $pic->pic_nama          = $request->nama;
        $pic->pic_keterangan    = $request->keterangan;
        $pic->jabatan_id        = $request->jabatan;
        $pic->kontrak_id        = $request->kontrak;
        $pic->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $pic = PIC::find($id);
        $pic->pic_nama          = $request->nama;
        $pic->pic_keterangan    = $request->keterangan;
        $pic->jabatan_id        = $request->jabatan;
        $pic->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pic = PIC::find($id);
        $pic->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
