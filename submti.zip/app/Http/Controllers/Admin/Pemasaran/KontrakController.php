<?php

namespace App\Http\Controllers\Admin\Pemasaran;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Jabatan;
use App\Model\Pemasaran\Koreksi;
use App\Model\Pemasaran\Kontrak;
use App\Model\Pemasaran\PIC;
use App\Model\Pemasaran\Store;
use App\User;
use Illuminate\Support\Facades\Hash;
use Session;

class KontrakController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $kontrak    = Kontrak::orderBy('created_at','desc')->get();
        return view('admin.pemasaran.v_kontrak')->with(compact('kontrak'));
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pemasaran.i_kontrak');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'username'  => ['required', 'string', 'max:255', 'unique:users,email'],
            'password'  => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        $last = Kontrak::select('kontrak_id')->orderBy('kontrak_id','desc')->first();
        
        if($last){
            $kode = $last->kontrak_id + 1;
        }else{
            $kode = 1;
        }

        $klien      = preg_replace('/\s+/', '', $request->nama_klien);
        $bulan      = date('m', strtotime($request->mulai));
        $tahun      = date('Y', strtotime($request->mulai));
        $kodifikasi = $kode.'/'.$klien.'/'.$bulan.'/'.$tahun;

        $user   = new User;
        $user->email            = $request->username;
        $user->name             = $request->username;
        $user->password         = Hash::make($request->password);
        $user->password_show    = $request->password;
        $user->address          = $request->alamat;
        $user->image            = 'avatar.png';
        $user->save();

        $user->attachRole('4');

        $userid = User::select('id')->orderBy('id','desc')->first();

        $kontrak = new Kontrak;
        $kontrak->kontrak_kode          = $kodifikasi;
        $kontrak->kontrak_klien_nama    = $request->nama_klien;
        $kontrak->kontrak_klien_alamat  = $request->alamat_klien;
        $kontrak->kontrak_mulai         = $request->mulai;
        $kontrak->kontrak_selesai       = $request->selesai;
        $kontrak->kontrak_mdi_ke        = $request->mdi_ke;
        $kontrak->kontrak_mdi_dasar     = str_replace('.','', $request->mdi_tambahan);
        $kontrak->kontrak_mdi_tambahan  = str_replace('.','', $request->mdi_tambahan);
        $kontrak->kontrak_mdk_ke        = $request->mdk_ke;
        $kontrak->kontrak_mdk_dasar     = str_replace('.','', $request->mdk_tambahan);
        $kontrak->kontrak_mdk_tambahan  = str_replace('.','', $request->mdk_tambahan);
        $kontrak->kontrak_pajak         = $request->pajak;
        $kontrak->user_id               = $userid->id;
        $kontrak->save();

        Session::flash('success','Kontrak Berhasil di Buat!');
        return redirect()->route('kontrak.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $kontrak    = Kontrak::find($id);
        $pic        = PIC::where('kontrak_id',$kontrak->kontrak_id)->orderBy('pic_nama')->get();
        $jabatan    = Jabatan::orderBy('jabatan_nama')->get();
        $store      = Store::where('kontrak_id',$kontrak->kontrak_id)->get();
        $koreksi    = Koreksi::where('kontrak_id',$kontrak->kontrak_id)->get();
        return view('admin.pemasaran.d_kontrak')->with(compact('kontrak','pic','jabatan','store','koreksi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kontrak    = Kontrak::find($id);
        return view('admin.pemasaran.e_kontrak')->with(compact('kontrak'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $last = Kontrak::select('kontrak_id')->orderBy('kontrak_id','desc')->first();

        $kode = $last->kontrak_id + 1;
        
        // if($last->kontrak_id){
        //     if($last->kontrak_id < 100){
        //         $kode = "00".$last->kontrak_id + 1;
        //     }elseif($last->kontrak_id < 10){
        //         $kode = "0".$last->kontrak_id + 1;
        //     }else{
        //         $kode = $last->kontrak_id + 1;
        //     }
        // }else{
        //     $kode = "001";
        // }

        $klien      = preg_replace('/\s+/', '', $request->nama_klien);
        $bulan      = date('m', strtotime($request->mulai));
        $tahun      = date('Y', strtotime($request->mulai));
        $kodifikasi = $kode.'/'.$klien.'/'.$bulan.'/'.$tahun;

        $kontrak = Kontrak::find($id);
        $kontrak->kontrak_kode          = $kodifikasi;
        $kontrak->kontrak_klien_nama    = $request->nama_klien;
        $kontrak->kontrak_klien_alamat  = $request->alamat_klien;
        $kontrak->kontrak_mulai         = $request->mulai;
        $kontrak->kontrak_selesai       = $request->selesai;
        $kontrak->kontrak_mdi_ke        = $request->mdi_ke;
        $kontrak->kontrak_mdi_dasar     = str_replace('.','', $request->mdi_tambahan);
        $kontrak->kontrak_mdi_tambahan  = str_replace('.','', $request->mdi_tambahan);
        $kontrak->kontrak_mdk_ke        = $request->mdk_ke;
        $kontrak->kontrak_mdk_dasar     = str_replace('.','', $request->mdk_tambahan);
        $kontrak->kontrak_mdk_tambahan  = str_replace('.','', $request->mdk_tambahan);
        $kontrak->kontrak_pajak         = $request->pajak;
        $kontrak->save();

        Session::flash('success','Kontrak Berhasil di Ubah!');
        return redirect()->route('kontrak.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kontrak = Kontrak::find($id);
        $kontrak->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->route('kontrak.index');
    }

    public function download_tarif()
    {
        return response()->download(public_path('file_store/tarif.xlsx'));
    }

    public function download_store()
    {
        return response()->download(public_path('file_store/store.xlsx'));
    }
}
