<?php

namespace App\Http\Controllers\Admin\Pemasaran;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Imports\TarifImport;
use App\Model\Master\JenisKendaraan;
use App\Model\Pemasaran\Store;
use App\Model\Pemasaran\Tarif;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class TarifController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {   
        $store  = Store::find($request->store);
        $jenis  = JenisKendaraan::orderBy('jenis_kendaraan_nama')->get();
        return view('admin.pemasaran.i_tarif')->with(compact('store','jenis'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $store  = $request->store;

        if($request->tarif != null){
            $t = str_replace('.','', $request->tarif);
        }

        if($request->uj != null){
            $uj = str_replace('.','', $request->uj);
        }

        $tarif  = new Tarif;
        $tarif->tarif_klien                 = $t;
        $tarif->tarif_klien_md_luar_kota    = $request->mklk;
        $tarif->tarif_klien_md_dalam_kota   = $request->mkdk;
        $tarif->tarif_klien_bongkar_muat    = $request->bbmc;
        $tarif->tarif_klien_lain            = $request->blk;
        $tarif->tarif_mti_uang_jalan        = $uj;
        $tarif->tarif_mti_md_luar_kota      = $request->mmlk;
        $tarif->tarif_mti_md_dalam_kota     = $request->mmdk;
        $tarif->tarif_mti_bongkar_muat      = $request->bbmm;
        $tarif->tarif_mti_ritase            = $request->ritase;
        $tarif->tarif_mti_lain              = $request->blm;
        $tarif->tarif_keterangan            = $request->ket;
        $tarif->store_id                    = $request->store;
        $tarif->jenis_kendaraan_id          = $request->jkend;
        $tarif->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->route('tarif.show',$store);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $store  = Store::find($id);
        $tarif  = Tarif::where('store_id',$id)->get();
        return view('admin.pemasaran.v_tarif')->with(compact('store','tarif'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tarif  = Tarif::find($id);
        $jenis  = JenisKendaraan::orderBy('jenis_kendaraan_nama')->get();
        return view('admin.pemasaran.e_tarif')->with(compact('tarif','jenis'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if($request->tarif != null){
            $t = str_replace('.','', $request->tarif);
        }

        if($request->uj != null){
            $uj = str_replace('.','', $request->uj);
        }

        $tarif  = Tarif::find($id);
        $tarif->tarif_klien                 = $t;
        $tarif->tarif_klien_md_luar_kota    = $request->mklk;
        $tarif->tarif_klien_md_dalam_kota   = $request->mkdk;
        $tarif->tarif_klien_bongkar_muat    = $request->bbmc;
        $tarif->tarif_klien_lain            = $request->blk;
        $tarif->tarif_mti_uang_jalan        = $uj;
        $tarif->tarif_mti_md_luar_kota      = $request->mmlk;
        $tarif->tarif_mti_md_dalam_kota     = $request->mmdk;
        $tarif->tarif_mti_bongkar_muat      = $request->bbmm;
        $tarif->tarif_mti_ritase            = $request->ritase;
        $tarif->tarif_mti_lain              = $request->blm;
        $tarif->tarif_keterangan            = $request->ket;
        $tarif->jenis_kendaraan_id          = $request->jkend;
        $tarif->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('tarif.show',$tarif->store_id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $tarif  = Tarif::find($id);
        $tarif->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }

    public function import(Request $request)
    {
        $this->validate($request,[
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);

        Excel::import(new TarifImport, $request->file('file'));

        Session::flash('success','Data berhasil di export ke database!');
        return redirect()->back();
    }
}
