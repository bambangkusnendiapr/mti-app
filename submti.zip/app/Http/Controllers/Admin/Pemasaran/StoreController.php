<?php

namespace App\Http\Controllers\Admin\Pemasaran;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Imports\StoreImport;
use App\Model\Master\Kota;
use App\Model\Master\Provinsi;
use App\Model\Pemasaran\Kontrak;
use App\Model\Pemasaran\Store;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class StoreController extends Controller
{
    public function create(Request $request)
    {
        $kontrak    = Kontrak::find($request->kontrak);
        $provinsi   = Provinsi::orderBy('name')->get();
        return view('admin.pemasaran.i_store')->with(compact('kontrak','provinsi'));
    }

    public function edit(Request $request, $id)
    {
        $store      = Store::find($id);
        $provinsi   = Provinsi::orderBy('name')->get();
        $kota       = Kota::where('province_id',$store->provinsi_id)->get();
        return view('admin.pemasaran.e_store')->with(compact('store','provinsi','kota'));
    }

    public function store(Request $request)
    {   
        // $this->validate($request,[
        //     'kode'  => ['required', 'string', 'max:25', 'unique:tb_store,store_kode'],
        // ]);
        
        $kontrak = Kontrak::find($request->kontrak);

        $store  = new Store;
        $store->store_kode          = $request->kode;
        $store->store_nama          = $request->nama;
        $store->store_alamat        = $request->alamat;
        $store->store_region        = $request->region;
        $store->store_keterangan    = $request->keterangan;
        $store->provinsi_id         = $request->provinsi;
        $store->kota_id             = $request->kota;
        $store->kontrak_id          = $request->kontrak;
        $store->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->route('kontrak.show',$kontrak->kontrak_id);
    }

    public function update(Request $request, $id)
    {   
        // $this->validate($request,[
        //     'kode'  => ['required', 'string', 'max:25', 'unique:tb_store,store_kode'],
        // ]);

        $store  = Store::find($id);
        $store->store_kode          = $request->kode;
        $store->store_nama          = $request->nama;
        $store->store_alamat        = $request->alamat;
        $store->store_region        = $request->region;
        $store->store_keterangan    = $request->keterangan;
        $store->provinsi_id         = $request->provinsi;
        $store->kota_id             = $request->kota;
        $store->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('kontrak.show',$store->kontrak->kontrak_id);
    }

    public function destroy($id)
    {
        $store  = Store::find($id);
        $store->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }

    public function import(Request $request)
    {
        $this->validate($request,[
            'file' => 'required|mimes:csv,xls,xlsx'
        ]);

        Excel::import(new StoreImport, $request->file('file'));

        Session::flash('success','Data berhasil di export ke database!');
        return redirect()->back();
    }
}
