<?php

namespace App\Http\Controllers\Admin\Other;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Kendaraan;
use App\Model\Master\Partner;
use App\Model\Other\PaymentPartner;
use App\Model\Other\Purchasing;
use Session;

class PurchasingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $partner    = Partner::all();
        $purchasing = Purchasing::all();
        $kendaraan  = Kendaraan::orderBy('kendaraan_nopol','asc')->get();
        return view('admin.other.purchasing')->with(compact('partner','purchasing','kendaraan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $purchasing = new Purchasing;
        $purchasing->purchasing_tanggal      = $request->tanggal;
        $purchasing->purchasing_jumlah       = str_replace('.','',$request->jumlah);
        $purchasing->purchasing_uraian       = $request->uraian;
        $purchasing->purchasing_keterangan   = $request->ket;
        $purchasing->partner_id              = $request->partner;
        $purchasing->kendaraan_id            = $request->kendaraan;
        $purchasing->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $purchasing = Purchasing::find($id);
        $purchasing->purchasing_tanggal      = $request->tanggal;
        $purchasing->purchasing_jumlah       = str_replace('.','',$request->jumlah);
        $purchasing->purchasing_uraian       = $request->uraian;
        $purchasing->purchasing_keterangan	 = $request->ket;
        $purchasing->partner_id              = $request->partner;
        $purchasing->kendaraan_id            = $request->kendaraan;
        $purchasing->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $purchasing = Purchasing::where('purchasing_id',$id)->first();
        $purchasing->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }

    /**
     * Payment Area
     */

    public function payment_index($id)
    {
        $payment    = PaymentPartner::where('purchasing_id',$id)->get();
        $purchasing = Purchasing::find($id);
        return view('admin.other.payment')->with(compact('payment','purchasing'));
    }

    public function payment_store(Request $request)
    {
        $payment = new PaymentPartner;
        $payment->payment_partner_tgl           = $request->tanggal;
        $payment->payment_partner_uraian        = $request->uraian;
        $payment->payment_partner_satuan        = $request->satuan;
        $payment->payment_partner_banyak        = str_replace('.','',$request->banyak);
        $payment->payment_partner_harga_satuan  = str_replace('.','',$request->harga);
        $payment->payment_partner_jumlah        = str_replace('.','',$request->banyak) * str_replace('.','',$request->harga);
        $payment->payment_partner_keterangan    = $request->keterangan;
        $payment->purchasing_id                 = $request->purchasing;
        $payment->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->back();
    }

    public function payment_update(Request $request, $id)
    {
        $payment = PaymentPartner::find($id);
        $payment->payment_partner_tgl           = $request->tanggal;
        $payment->payment_partner_uraian        = $request->uraian;
        $payment->payment_partner_satuan        = $request->satuan;
        $payment->payment_partner_banyak        = str_replace('.','',$request->banyak);
        $payment->payment_partner_harga_satuan  = str_replace('.','',$request->harga);
        $payment->payment_partner_jumlah        = str_replace('.','',$request->banyak) * str_replace('.','',$request->harga);
        $payment->payment_partner_keterangan    = $request->keterangan;
        $payment->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    public function payment_destroy($id)
    {

    }
}
