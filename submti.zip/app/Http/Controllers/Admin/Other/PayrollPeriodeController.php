<?php

namespace App\Http\Controllers\Admin\Other;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Other\PayrollPeriode;
use Session;
class PayrollPeriodeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $periode = PayrollPeriode::all();
        return view('admin.other.payroll_periode')->with(compact('periode'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $periode = new PayrollPeriode;

        $periode->periode_tanggal = $request->tanggal;
        $periode->periode_keterangan = $request->ket;
        $periode->save();

        Session::flash('success','Data Berhasil di Simpan!');

        return redirect()->route('payroll-periode.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $periode = PayrollPeriode::find($id);

        $periode->periode_tanggal = $request->tanggal;
        $periode->periode_keterangan = $request->ket;
        $periode->update();

        Session::flash('success','Data Berhasil di Ubah!');

        return redirect()->route('payroll.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $periode = PayrollPeriode::find($id);
        $periode->destroy();

        Session::flash('success','Data Berhasil di Hapus!');

        return redirect()->route('payroll.index');
    }
}
