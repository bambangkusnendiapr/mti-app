<?php

namespace App\Http\Controllers\Admin\Other;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Kendaraan;
use App\Model\Other\Leasing;
use App\Model\Other\PaymentLeasing;
use Session;

class LeasingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kendaraan  = Kendaraan::all();
        $leasing    = Leasing::all();
        return view('admin.other.leasing')->with(compact('kendaraan','leasing'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $leasing = new Leasing;
        $leasing->kendaraan_id  = $request->kendaraan;
        $leasing->leasing_tgl   = $request->tanggal;
        $leasing->leasing_ket   = $request->keterangan;
        $leasing->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $leasing = Leasing::find($id);
        $leasing->kendaraan_id  = $request->kendaraan;
        $leasing->leasing_tgl   = $request->tanggal;
        $leasing->leasing_ket   = $request->keterangan;
        $leasing->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $leasing = Leasing::find($id);
        $leasing->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }

    /**
     * Leasing Payment Area
     */

    public function payment_index($id)
    {
        $leasing = Leasing::find($id);
        $payment = PaymentLeasing::where('leasing_id',$id)->get();
        return view('admin.other.leasing_payment')->with(compact('leasing','payment'));
    }

    public function payment_store(Request $request)
    {
        $payment = new PaymentLeasing;
        $payment->leasing_payment_tgl   = $request->tanggal;
        $payment->leasing_payment_ket   = $request->ket;
        $payment->leasing_id            = $request->leasing;
        $payment->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    public function payment_update(Request $request, $id)
    {
        $payment = PaymentLeasing::find($id);
        $payment->leasing_payment_tgl   = $request->tanggal;
        $payment->leasing_payment_ket   = $request->ket;
        $payment->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    public function payment_destroy($id)
    {
        $payment = PaymentLeasing::find($id);
        $payment->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
