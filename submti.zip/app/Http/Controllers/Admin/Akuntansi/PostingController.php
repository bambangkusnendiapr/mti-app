<?php

namespace App\Http\Controllers\Admin\Akuntansi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Akuntansi\KodeAkun;
use App\Model\Akuntansi\Posting;
use App\Model\Akuntansi\Transaksi;

class PostingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request('search')) {
            $posting    = Posting::orderBy('id','desc')->where('uraian', 'like', '%'.request('search'). '%')->orWhere('keterangan', 'like', '%'.request('search'). '%')->paginate(20);

            $posting->appends(['search' => request('search')]);
        } else {
            $posting    = Posting::orderBy('id','desc')->paginate(20);
        }

        $ka         = KodeAkun::orderBy('kode_akun','asc')->get();

        return view('admin.akuntansi.posting')->with(compact('posting','ka'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {


    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $posting = new Posting;
        $posting->tanggal       = $request->tanggal;
        $posting->uraian        = $request->uraian;
        $posting->keterangan    = $request->keterangan;
        // $posting->akun_db       = $request->akun_db;
        // $posting->debit         = $request->debit;
        // $posting->akun_kd       = $request->akun_kd;
        // $posting->kredit       = $request->kredit;
        $posting->save();
            // dd($posting);

        return redirect()->route('posting.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $posting = Posting::find($id);
        $posting->tanggal       = $request->tanggal;
        $posting->uraian        = $request->uraian;
        $posting->keterangan    = $request->keterangan;
        // $posting->akun_db       = $request->akun_db;
        // $posting->debit         = $request->debit;
        // $posting->akun_kd       = $request->akun_kd;
        // $posting->kredit        = $request->kredit;
        $posting->save();
        // return redirect()->route('posting.index');

        if($request->search != null && $request->page != null) {
            return redirect('/akuntansi/posting?search='.$request->search.'&page='.$request->page);
        } else if($request->search == null && $request->page != null) {
            return redirect('/akuntansi/posting?page='.$request->page);
        } else if($request->search != null && $request->page == null) {
            return redirect('/akuntansi/posting?search='.$request->search);
        } else {
            return redirect()->route('posting.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $posting = Posting::find($id);
        $posting->delete();
        Transaksi::where('posting_id',$id)->delete();
        return redirect()->route('posting.index');
    }

   
}
