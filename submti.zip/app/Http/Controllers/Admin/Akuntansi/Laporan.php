<?php

namespace App\Http\Controllers\Admin\Akuntansi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Akuntansi\Posting;
use App\Model\Akuntansi\Transaksi;
use App\Model\Akuntansi\KodeAkun;
use App\Exports\JurnalExport;
use App\Exports\TransExport;
use Maatwebsite\Excel\Facades\Excel;


class Laporan extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function bukubesar(Request $request){
        $kda = $request->kda;
        if( $kda == "Tampilkan Semua")
            $kode_akun  = KodeAkun::orderBy('kode_akun','asc')->get();
        else
            $kode_akun  = KodeAkun::where('id',$kda)->get();

        $dari = $request->tgl1;
        $ke   = $request->tgl2;

        return view('admin.akuntansi.buku_besar')->with(compact('kode_akun','dari','ke'));

    }

    public function labarugi(Request $request){
        $dari = $request->tgl1;
        $ke   = $request->tgl2;
        $transaksi  = Transaksi::all();
        $trade      = Transaksi::select('kode_akun')->groupBy('kode_akun')->whereBetween('tanggal',[$dari,$ke])->get();

        return view('admin.akuntansi.laba_rugi')->with(compact('dari','ke','transaksi','trade'));
    }

    public function neraca(Request $request){
        $dari = $request->tgl1;
        $ke   = $request->tgl2;
        $transaksi  = Transaksi::all();
        $trade      = Transaksi::select('kode_akun')->groupBy('kode_akun')->whereBetween('tanggal',[$dari,$ke])->get();

        return view('admin.akuntansi.neraca')->with(compact('dari','ke','transaksi','trade'));
    }

    public function cashflow(Request $request){
        $dari = $request->tgl1;
        $ke   = $request->tgl2;
        $transaksi  = Transaksi::all();
        $trade      = Transaksi::select('kode_akun')->groupBy('kode_akun')->whereBetween('tanggal',[$dari,$ke])->get();

        return view('admin.akuntansi.cash_flow')->with(compact('dari','ke','transaksi','trade'));
    }

    public function exjurnal()
	{
		return Excel::download(new JurnalExport, 'jurnal.xlsx');
    }

    public function extrans()
	{
		return Excel::download(new TransExport, 'transaksi.xlsx');
	}

}

