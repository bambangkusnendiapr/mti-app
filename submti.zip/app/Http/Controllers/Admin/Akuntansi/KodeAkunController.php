<?php

namespace App\Http\Controllers\Admin\Akuntansi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Akuntansi\KodeAkun;

class KodeAkunController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kode_akun= KodeAkun::orderBy('kode_akun','asc')->get();
        return view('admin.akuntansi.kode_akun')->with(compact('kode_akun'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $kd_akun = new KodeAkun ;

        $saldo = $request->saldo_awal;

        if($saldo == "0"){
            $saldo = 0;
        }$saldo = $request->saldo_awal;

        $kd_akun->kode_akun     = $request->kode_akun;
        $kd_akun->nama_akun     = $request->nama_akun;
        $kd_akun->saldo_awal    = str_replace('.','', $saldo);
        $kd_akun->normal        = $request->normal;
        $kd_akun->kelompok      = $request->kelompok;
        $kd_akun->cash_flow     = $request->cashflow;
        $kd_akun->save();
        // dd($kd_akun);
        return redirect()->route('kode-akun.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $kd_akun = KodeAkun::find($id);
        $saldo = $request->saldo_awal;
        $kd_akun->kode_akun = $request->kode_akun;
        $kd_akun->nama_akun = $request->nama_akun;
        $kd_akun->saldo_awal = str_replace('.','', $saldo);
        $kd_akun->normal = $request->normal;
        $kd_akun->kelompok = $request->kelompok;
        $kd_akun->cash_flow = $request->cashflow;
        $kd_akun->update();
        // dd($kd_akun);
        return redirect()->route('kode-akun.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kd_akun = KodeAkun::find($id);
        $kd_akun->delete();
        // dd($kd_akun);
        return redirect()->route('kode-akun.index');
    }

    public function ajax($id){

        $ka = KodeAkun::find($id);

        return $ka;

    }
}
