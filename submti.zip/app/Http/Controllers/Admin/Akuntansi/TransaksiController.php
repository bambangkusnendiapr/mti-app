<?php

namespace App\Http\Controllers\Admin\Akuntansi;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Akuntansi\Transaksi;
class TransaksiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $saldo1 = $request->debet_1;
        $saldo2 = $request->kredit_2;
        
        $this->validate($request,[
            'kode_akun_1'  => 'required',
            'kode_akun_2'  => 'required',
        ]);
        
        
        $debet = new Transaksi;
        $debet->posting_id     = $request->id_posting;
        $debet->tanggal        = $request->tanggal;
        $debet->kode_akun      = $request->kode_akun_1;
        $debet->debet          = str_replace('.','', $saldo1);;
        $debet->kredit         = $request->kredit_1;
        $debet->save();

        $kredit = new Transaksi;
        $kredit->posting_id     = $request->id_posting;
        $kredit->tanggal        = $request->tanggal;
        $kredit->kode_akun      = $request->kode_akun_2;
        $kredit->debet          = $request->debet_2;
        $kredit->kredit         = str_replace('.','', $saldo2);;
        $kredit->save();

        return redirect()->route('posting.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $tran = Transaksi::find($id);

        $trans = Transaksi::where('created_at',$tran->created_at)->delete();
        // dd($trans);
       
        return redirect()->route('posting.index');
    }
}
