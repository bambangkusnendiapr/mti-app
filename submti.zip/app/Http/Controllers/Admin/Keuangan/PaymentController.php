<?php

namespace App\Http\Controllers\Admin\Keuangan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Keuangan\Invoice;
use App\Model\Keuangan\InvoiceDetail;
use App\Model\Keuangan\Payment;
use Session;

class PaymentController extends Controller
{
    public function belum_index()
    {
        $invoice = Invoice::where('invoice_status',null)->orderBy('created_at','desc')->get();
        return view('admin.keuangan.v_payment')->with(compact('invoice'));
    }

    public function belum_show($id)
    {
        $invoice = Invoice::find($id);
        $payment = Payment::where('invoice_id',$invoice->invoice_id)->orderBy('created_at','desc')->get();
        return view('admin.keuangan.d_payment')->with(compact('invoice','payment'));
    }

    public function belum_store(Request $request)
    {
        $payment = new Payment;
        $payment->payment_bayar     = str_replace('.','',$request->payment);
        $payment->payment_tanggal   = $request->tanggal;
        $payment->invoice_id        = $request->invoice;
        $payment->save(); 

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    public function belum_update(Request $request, $id)
    {
        $payment = new Payment;
        $payment->payment_bayar     = str_replace('.','',$request->payment);
        $payment->payment_tanggal   = $request->tanggal;
        $payment->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    public function belum_lunas($id)
    {
        $invoice = Invoice::find($id);
        $invoice->invoice_status    = 1;
        $invoice->save();

        Session::flash('success','Pembayaran telah lunas!');
        return redirect()->back();
    }

    public function lunas_index()
    {
        $invoice = Invoice::where('invoice_status','1')->get();
        $lunas = 'lunas';
        return view('admin.keuangan.v_payment')->with(compact('invoice','lunas'));
    }

    public function payment_delete($id)
    {
        $payment = Payment::find($id)->delete();

        Session::flash('success','Data berhasil di Hapus!');
        return redirect()->back();
    }
}
