<?php

namespace App\Http\Controllers\Admin\Keuangan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Keuangan\Reconcile;
use App\Model\Operasional\SuratJalan;
use Session;

class SuratJalanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sj = SuratJalan::where('surat_jalan_status','1')->orWhere('surat_jalan_status','2')->orWhere('surat_jalan_status','3')->orderBy('created_at','desc')->get();
        return view('admin.keuangan.v_sj')->with(compact('sj'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $tarif = 0; $mdk = 0; $add = 0;

        if($request->tarif != null || $request->tarif != 0){
            $tarif = str_replace('.','',$request->tarif);
        }else{
            $tarif = 0;
        }
        
        if($request->mdk != null || $request->mdk != 0){
            $mdk = str_replace('.','',$request->mdk);
        }else{
            $mdk = 0;
        }

        if($request->add != null || $request->add != 0){
            $add = str_replace('.','',$request->add);
        }else{
            $add = 0;
        }
        
        
        $sj = SuratJalan::find($id);

        $rec = new Reconcile;
        $rec->reconcile_tarif        = $tarif;
        $rec->reconcile_uang_jalan   = $sj->surat_jalan_uang_jalan;
        $rec->reconcile_mdk          = $mdk;
        $rec->reconcile_mdi          = $sj->surat_jalan_mdi;
        $rec->reconcile_klien_total  = $tarif + $mdk + $add;
        $rec->reconcile_mti_total    = $sj->surat_jalan_mti_total;
        $rec->surat_jalan_id         = $sj->surat_jalan_id;
        $rec->kontrak_id             = $sj->kontrak_id;
        $rec->save();

        $sj->surat_jalan_status = 3;
        $sj->save();

        Session::flash('success','Data selesai di Reconcile');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function terima($id)
    {
        $sj = SuratJalan::find($id);
        $sj->surat_jalan_status = 2;
        $sj->save();

        Session::flash('success','Surat Jalan di Terima!');
        return redirect()->back();
    }
}
