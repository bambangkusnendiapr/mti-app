<?php

namespace App\Http\Controllers\Admin\Keuangan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Keuangan\Invoice;
use App\Model\Keuangan\InvoiceDetail;
use App\Model\Keuangan\Reconcile;
use App\Model\Master\Karyawan;
use App\Model\Pemasaran\Kontrak;
use Session;

class InvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $invoice = Invoice::orderBy('created_at','desc')->get();
        return view('admin.keuangan.v_invoice')->with(compact('invoice'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kontrak    = Kontrak::all();
        $karyawan   = Karyawan::orderBy('karyawan_nama','asc')->get();
        return view('admin.keuangan.i_invoice')->with(compact('kontrak','karyawan'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $invoice = new Invoice;
        $invoice->kontrak_id        = $request->kontrak;
        $invoice->invoice_tanggal   = $request->tgl;
        $invoice->invoice_kode      = $request->kode;
        $invoice->karyawan_id       = $request->oleh;
        $invoice->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->route('invoice.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $invoice    = Invoice::find($id);
        $idetail    = InvoiceDetail::where('invoice_id',$invoice->invoice_id)->orderBy('created_at','desc')->get();
        $reconcile  = Reconcile::where('kontrak_id',$invoice->kontrak_id)->orderBy('created_at','desc')->get();
        return view('admin.keuangan.d_invoice')->with(compact('invoice','idetail','reconcile'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $invoice = Invoice::find($id);
        $kontrak = Kontrak::all();
        $karyawan   = Karyawan::where('jabatan_id',2)->get();
        return view('admin.keuangan.e_invoice')->with(compact('invoice','kontrak','karyawan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $invoice = Invoice::find($id);
        $invoice->kontrak_id        = $request->kontrak;
        $invoice->invoice_tanggal   = $request->tgl;
        $invoice->invoice_kode      = $request->kode;
        $invoice->karyawan_id       = $request->oleh;
        $invoice->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('invoice.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $invoice = Invoice::find($id);
        $invoice->delete();
        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->route('invoice.index');
    }

    /**
     * Function Tambahan
     */

    public function cetak($id)
    {
        $invoice = Invoice::find($id);
        return view('admin.keuangan.l_invoice')->with(compact('invoice'));
    }

    public function detailstore(Request $request)
    {
        $idetail = new InvoiceDetail;
        $idetail->invoice_id    = $request->invoice;
        $idetail->reconcile_id  = $request->reconcile;
        $idetail->save();
        
        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    public function detailupdate(Request $request, $id)
    {
        $idetail = InvoiceDetail::find($id);
        $idetail->invoice_id    = $request->invoice;
        $idetail->save();
        
        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    public function detaildestroy($id)
    {
        $idetail = InvoiceDetail::find($id)->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
