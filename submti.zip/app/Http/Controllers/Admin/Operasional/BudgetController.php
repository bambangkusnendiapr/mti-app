<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Driver;
use App\Model\Master\JenisKendaraan;
use App\Model\Master\Kendaraan;
use App\Model\Operasional\Budget;
use App\Model\Operasional\PO;
use App\Model\Pemasaran\Kontrak;
use App\Model\Pemasaran\Store;
use Session;

class BudgetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {   
        $po         = PO::find($id);
        $jenis      = JenisKendaraan::all();
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $driver     = Driver::all();
        return view('admin.operasional.cabang.i_budget')->with(compact('po','jenis','kontrak','driver'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $budget = new Budget;
        $budget->jenis_kendaraan_id = $request->jenis;
        $budget->kendaraan_id       = $request->nopol;
        $budget->budget_catatan     = $request->cat;
        $budget->kontrak_id         = $request->budget;
        $budget->user_id            = $request->id;
        $budget->po_id              = $request->po;
        $budget->driver_id          = $request->driver;
        $budget->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->route('budget.show',$request->po);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $po         = PO::find($id);
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $budget     = Budget::where('po_id',$id)->get();
        $store      = Store::where('kontrak_id',$kontrak->kontrak_id)->get();
        return view('admin.operasional.cabang.v_budget')->with(compact('po','kontrak','budget','store'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $budget     = Budget::find($id);
        $jenis      = JenisKendaraan::all();
        $kendaraan  = Kendaraan::where('jenis_kendaraan_id',$budget->jenis_kendaraan_id)->get();
        $driver     = Driver::all();
        return view('admin.operasional.cabang.e_budget')->with(compact('budget','jenis','kendaraan','driver'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $budget = Budget::find($id);
        $budget->jenis_kendaraan_id = $request->jenis;
        $budget->kendaraan_id       = $request->nopol;
        $budget->budget_catatan     = $request->cat;
        $budget->driver_id          = $request->driver;
        $budget->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('budget.show',$request->po);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $budget = Budget::find($id);
        $budget->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }

    /**
     * Fungsi Tambahan
     */

    public function pengajuan(Request $request, $id)
    {
        $budget = Budget::find($id);
        $budget->budget_uang_jalan  = $request->buj; 
        $budget->budget_tarif       = $request->kt; 
        $budget->budget_mdi         = $request->mdi;
        $budget->budget_mdk         = $request->mdk;
        $budget->save();

        Session::flash('success','Dana Budget di Ajukan!');
        return redirect()->back();
    }

}
