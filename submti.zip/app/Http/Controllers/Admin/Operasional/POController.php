<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\PO;
use App\Model\Pemasaran\Kontrak;
use App\Model\Pemasaran\PIC;
use Session;

class POController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $po         = PO::where('kontrak_id',$kontrak->kontrak_id)->orderBy('created_at','desc')->get();
        return view('admin.operasional.cabang.v_po')->with(compact('po','kontrak'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $pic        = PIC::where('kontrak_id',$kontrak->kontrak_id)->get();
        return view('admin.operasional.cabang.i_po')->with(compact('pic','kontrak'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $po = new PO;
        $po->po_kode            = $request->kd_po;
        $po->po_tanggal         = $request->tgl_po;
        $po->po_mdi_ke          = $request->mdi_ke;
        $po->po_mdi_dasar       = str_replace('.','',$request->mdi_tambahan);
        $po->po_mdi_tambahan    = str_replace('.','',$request->mdi_tambahan);
        $po->po_mdk_ke          = $request->mdk_ke;
        $po->po_mdk_dasar       = $request->mdk_tambahan;
        $po->po_mdk_tambahan    = $request->mdk_tambahan;
        $po->po_catatan         = $request->cat;
        $po->pic_id             = $request->pic;
        $po->kontrak_id         = $request->kontrak;
        $po->save();

        Session::flash('success','Data Berhasil di Input!');
        return redirect()->route('po.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {   
        $po         = PO::find($id);
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $pic        = PIC::where('kontrak_id',$kontrak->kontrak_id)->get();
        return view('admin.operasional.cabang.e_po')->with(compact('po','pic','kontrak'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $po = PO::find($id);
        $po->po_kode            = $request->kd_po;
        $po->po_tanggal         = $request->tgl_po;
        $po->po_mdi_ke          = $request->mdi_ke;
        $po->po_mdi_dasar       = str_replace('.','',$request->mdi_tambahan);
        $po->po_mdi_tambahan    = str_replace('.','',$request->mdi_tambahan);
        $po->po_catatan         = $request->cat;
        $po->pic_id             = $request->pic;
        $po->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('po.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $po = PO::find($id);
        $po->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
