<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\Budget;
use App\Model\Operasional\BudgetStore;
use App\Model\Pemasaran\Tarif;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Session;

class BudgetStoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        try{
            $budget = Budget::find($request->budget_id);
            $tarif  = Tarif::where('jenis_kendaraan_id',$budget->jenis_kendaraan_id)->where('store_id',$request->store)->first();

            $bstore = new BudgetStore;
            $bstore->budgetstore_klien_tarif        = $tarif->tarif_klien;
            $bstore->budgetstore_klien_bongkar_muat = $tarif->tarif_klien_bongkar_muat;
            $bstore->budgetstore_klien_lain         = $tarif->tarif_klien_lain;
            $bstore->budgetstore_mti_uang_jalan     = $tarif->tarif_mti_uang_jalan + $request->tamkur;
            $bstore->budgetstore_mti_bongkar_muat   = $tarif->tarif_mti_bongkar_muat;
            $bstore->budgetstore_mti_ritase         = $tarif->tarif_mti_ritase;
            $bstore->budgetstore_mti_lain           = $tarif->tarif_mti_lain;
            $bstore->budget_id                      = $request->budget_id;
            $bstore->store_id                       = $request->store;
            $bstore->save();
        }catch (Exception $exception) {
            return back()->with('error','Data Detail Store tidak di Temukan! Silahkan lengkapi data!');
        }

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $bstore = BudgetStore::find($id);
        $bstore->delete();
        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
