<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\SJBarang;
use App\Model\Operasional\SuratJalan;
use Session;

class SJBarangController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $barang = new SJBarang;
        $barang->sj_barang_banyak   = $request->banyak;
        $barang->sj_barang_nama     = $request->nama;
        $barang->sj_barang_berat    = $request->berat;
        $barang->surat_jalan_id     = $request->surat_jalan;
        $barang->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $barang = SJBarang::where('surat_jalan_id',$id)->get();
        $sj     = SuratJalan::find($id);
        return view('admin.operasional.cabang.v_barang')->with(compact('barang','sj'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $barang = SJBarang::find($id);
        $barang->sj_barang_banyak   = $request->banyak;
        $barang->sj_barang_nama     = $request->nama;
        $barang->sj_barang_berat    = $request->berat;
        $barang->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $barang = SJBarang::find($id);
        $barang->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->back();
    }
}
