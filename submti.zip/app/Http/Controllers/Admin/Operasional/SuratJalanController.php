<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\SuratJalan;
use App\Model\Pemasaran\Kontrak;
use Session;

class SuratJalanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kontrak    = Kontrak::where('user_id',\Auth::user()->id)->first();
        $sj         = SuratJalan::where('kontrak_id',$kontrak->kontrak_id)->orderBy('created_at','desc')->get();
        return view('admin.operasional.cabang.v_sj')->with(compact('sj'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.operasional.i_sj');
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function cetak($id)
    {
        $sj = SuratJalan::find($id);
        return view('admin.operasional.cabang.l_sj')->with(compact('sj'));
    }

    public function terima($id)
    {
        $sj = SuratJalan::find($id);
        $sj->surat_jalan_status = 1;
        $sj->save();

        Session::flash('success','Surat Jalan di Terima!');
        return redirect()->back();
    }

}
