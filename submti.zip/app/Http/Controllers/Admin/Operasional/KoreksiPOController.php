<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\Budget;
use App\Model\Operasional\KoreksiPO;
use App\Model\Operasional\PO;
use App\Model\Pemasaran\Koreksi;
use Session;

class KoreksiPOController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        if($request->tarif != null){
            $tarif  = str_replace('.','',$request->tarif);
        }else{
            $tarif  = 0;
        }
        if($request->uang_jalan != null){
            $uang_jalan  = str_replace('.','',$request->uang_jalan);
        }else{
            $uang_jalan  = 0;
        }

        $kpo = new KoreksiPO;
        $kpo->koreksi_po_tarif      = $tarif;
        $kpo->koreksi_po_uang_jalan = $uang_jalan;
        $kpo->po_id                 = $request->po;
        $kpo->kontrak_id            = $request->kontrak;
        $kpo->koreksi_id            = $request->koreksi;
        $kpo->budget_id             = $request->budget;
        $kpo->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $budget     = Budget::find($id);
        $koreksi    = Koreksi::where('kontrak_id',$budget->po->kontrak->kontrak_id)->get();
        $kpo        = KoreksiPO::where('budget_id',$budget->budget_id)->get();
        return view('admin.operasional.cabang.v_koreksi_po')->with(compact('budget','kpo','koreksi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   
        if($request->tarif != null){
            $tarif  = str_replace('.','',$request->tarif);
        }else{
            $tarif  = 0;
        }
        if($request->uang_jalan != null){
            $uang_jalan  = str_replace('.','',$request->uang_jalan);
        }else{
            $uang_jalan  = 0;
        }

        $kpo = KoreksiPO::find($id);
        $kpo->koreksi_po_tarif      = $tarif;
        $kpo->koreksi_po_uang_jalan = $uang_jalan;
        // $kpo->po_id                 = $request->po;
        // $kpo->kontrak_id            = $request->kontrak;
        $kpo->koreksi_id            = $request->koreksi;
        $kpo->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kpo = KoreksiPO::find($id);
        $kpo->delete();

        Session::flash('success','Data Berhasil di Hapus');
        return redirect()->back();
    }
}
