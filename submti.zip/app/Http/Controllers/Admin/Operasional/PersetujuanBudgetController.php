<?php

namespace App\Http\Controllers\Admin\Operasional;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Operasional\Budget;
use App\Model\Operasional\SuratJalan;
use App\Model\Pemasaran\Koreksi;
use Session;

class PersetujuanBudgetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $budget     = Budget::orderBy('updated_at','desc')->get();
        $koreksi    = Koreksi::all();
        return view('admin.operasional.pusat.v_konfirmasi_pengajuan')->with(compact('budget','koreksi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $budget = Budget::find($id);
        return view('admin.operasional.pusat.e_persetujuan')->with(compact('budget'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $budget = Budget::find($id);
        $budget->budget_tarif       = str_replace('.','', $request->tarif) + str_replace('.','', $request->tarifed);
        $budget->budget_uang_jalan  = str_replace('.','', $request->uj) + str_replace('.','', $request->ujed);
        $budget->budget_mdk         = str_replace('.','', $request->mdk) + str_replace('.','', $request->mdked);
        $budget->budget_mdi         = str_replace('.','', $request->mdi) + str_replace('.','', $request->mdied);
        $budget->save();

        Session::flash('success','Data berhasil di Ubah!');
        return redirect()->route('persetujuanbudget.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function setujui($id)
    {
        $budget = Budget::find($id);
        $budget->budget_status  = 1;

        $sj     = new SuratJalan;
        $sj->surat_jalan_tarif          = $budget->budget_tarif;
        $sj->surat_jalan_uang_jalan     = $budget->budget_uang_jalan;
        $sj->surat_jalan_mdk            = $budget->budget_mdk;
        $sj->surat_jalan_mdi            = $budget->budget_mdi;
        $sj->surat_jalan_klien_total    = $budget->budget_tarif + $budget->budget_mdk + $budget->koreksi->sum('koreksi_po_tarif');
        $sj->surat_jalan_mti_total      = $budget->budget_uang_jalan + $budget->budget_mdi + $budget->koreksi->sum('koreksi_po_uang_jalan');
        $sj->budget_id                  = $budget->budget_id;
        $sj->kontrak_id                 = $budget->po->kontrak->kontrak_id;
        $sj->save();

        $budget->save();

        Session::flash('success','Pengajuan di Setujui!');
        return redirect()->back();
    }
}
