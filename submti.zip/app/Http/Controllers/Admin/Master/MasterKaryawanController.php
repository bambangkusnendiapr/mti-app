<?php

namespace App\Http\Controllers\Admin\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Jabatan;
use App\Model\Master\Karyawan;
use Session;

class MasterKaryawanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $karyawan   = Karyawan::orderBy('karyawan_nama')->get();
        $jabatan    = Jabatan::orderBy('jabatan_nama')->get();
        return view('admin.master.karyawan')->with(compact('karyawan','jabatan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $karyawan   = new Karyawan;
        $karyawan->karyawan_nama    = $request->nama;
        $karyawan->karyawan_alamat  = $request->alamat;
        $karyawan->karyawan_kota    = $request->kota;
        $karyawan->karyawan_no_telp = $request->telp;
        $karyawan->karyawan_agama   = $request->agama;
        $karyawan->karyawan_jk      = $request->jk;
        $karyawan->jabatan_id       = $request->jabatan;
        $karyawan->save();

        Session::flash('success','Data Berhasil di Simpan!');
        return redirect()->route('karyawan.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $karyawan   = Karyawan::find($id);
        $karyawan->karyawan_nama    = $request->nama;
        $karyawan->karyawan_alamat  = $request->alamat;
        $karyawan->karyawan_no_telp = $request->telp;
        $karyawan->karyawan_kota    = $request->kota;
        $karyawan->karyawan_agama   = $request->agama;
        $karyawan->karyawan_jk      = $request->jk;
        $karyawan->jabatan_id       = $request->jabatan;
        $karyawan->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('karyawan.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $karyawan   = Karyawan::find($id);
        $karyawan->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->route('karyawan.index');
    }
}
