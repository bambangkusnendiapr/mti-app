<?php

namespace App\Http\Controllers\Admin\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\JenisKendaraan;
use App\Model\Master\Kendaraan;
use App\Model\Master\Partner;
use Session;

class MasterKendaraanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $kendaraan  = Kendaraan::all();
        $partner    = Partner::all();
        $jenis      = JenisKendaraan::orderBy('jenis_kendaraan_nama')->get();
        return view('admin.master.kendaraan')->with(compact('kendaraan','jenis','partner'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $kendaraan = Kendaraan::groupBy('jenis_kendaraan_id')->having('jenis_kendaraan_id','>',1)->count();
        dd($kendaraan);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        
        $this->validate($request,[
            'nama'     => ['required', 'string', 'max:255'],
            'nopol'    => ['unique:master_kendaraan,kendaraan_nopol'],
        ]);

        $kendaraan = new Kendaraan;
        $kendaraan->kendaraan_nopol         = $request->nopol;
        $kendaraan->kendaraan_plat          = $request->warna;
        $kendaraan->kendaraan_nama          = $request->nama;
        $kendaraan->kendaraan_merk          = $request->merk;
        $kendaraan->kendaraan_jangka_waktu  = $request->waktu;
        $kendaraan->kendaraan_harga         = str_replace('.','', $request->harga);
        $kendaraan->kendaraan_angsuran      = str_replace('.','', $request->angsuran);
        $kendaraan->kendaraan_keterangan    = $request->keterangan;
        $kendaraan->kendaraan_jangka_sisa   = $request->sisa;
        $kendaraan->jenis_kendaraan_id      = $request->jenis;
        $kendaraan->partner_id              = $request->partner;
        $kendaraan->save();

        Session::flash('success','Data Berhasil di Tambah!');
        return redirect()->route('kendaraan.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {   

        $this->validate($request,[
            'nama'     => ['required', 'string', 'max:255'],
            // 'nopol'    => ['unique:master_kendaraan,kendaraan_nopol'],
        ]);

        $kendaraan = Kendaraan::find($id);
        $kendaraan->kendaraan_nopol         = $request->nopol;
        $kendaraan->kendaraan_plat          = $request->warna;
        $kendaraan->kendaraan_nama          = $request->nama;
        $kendaraan->kendaraan_merk          = $request->merk;
        $kendaraan->kendaraan_jangka_waktu  = $request->waktu;
        $kendaraan->kendaraan_harga         = str_replace('.','', $request->harga);
        $kendaraan->kendaraan_angsuran      = str_replace('.','', $request->angsuran);
        $kendaraan->kendaraan_keterangan    = $request->keterangan;
        $kendaraan->kendaraan_jangka_sisa   = $request->sisa;
        $kendaraan->jenis_kendaraan_id      = $request->jenis;
        $kendaraan->partner_id              = $request->partner;
        $kendaraan->save();

        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('kendaraan.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $kendaraan = Kendaraan::find($id);
        $kendaraan->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->route('kendaraan.index');
    }
}
