<?php

namespace App\Http\Controllers\Admin\Master;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Driver;
use Session;

class MasterDriverController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $driver = Driver::all();
        return view('admin.master.driver')->with(compact('driver'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   

        $this->validate($request,[
            'nama'     => ['required', 'string', 'max:255'],
            'ktp'      => ['unique:master_driver,driver_ktp'],
        ]);

        $driver = new Driver;
        $driver->driver_nama    = $request->nama;
        $driver->driver_ktp     = $request->ktp;
        $driver->driver_kontak  = $request->kontak;
        $driver->save();
        
        Session::flash('success','Data Berhasil di Input!');
        return redirect()->route('driver.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $driver = Driver::find($id);
        $driver->driver_nama    = $request->nama;
        $driver->driver_ktp     = $request->ktp;
        $driver->driver_kontak  = $request->kontak;
        $driver->save();
        
        Session::flash('success','Data Berhasil di Ubah!');
        return redirect()->route('driver.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $driver = Driver::find($id);
        $driver->delete();

        Session::flash('success','Data Berhasil di Hapus!');
        return redirect()->route('driver.index');
    }
}
