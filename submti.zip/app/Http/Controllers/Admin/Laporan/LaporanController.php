<?php

namespace App\Http\Controllers\Admin\Laporan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Keuangan\Invoice;
use App\Model\Keuangan\Reconcile;
use App\Model\Master\Kendaraan;
use App\Model\Master\Partner;
use App\Model\Operasional\Budget;
use App\Model\Operasional\SuratJalan;
use App\Model\Other\Leasing;
use App\Model\Other\Purchasing;
use App\Model\Pemasaran\Kontrak;

class LaporanController extends Controller
{
    public function surat_jalan_index()
    {
        return view('admin.laporan.laporan_sj');
    }

    public function surat_jalan_cetak(Request $request)
    {
        $dari   = $request->dari;
        $ke     = $request->ke;
        $sj     = SuratJalan::where('surat_jalan_status','!=',3)->whereBetween('created_at',[$dari,$ke])->get();
        // $sj     = SuratJalan::whereBetween('created_at',[$dari,$ke])->get();
        // $kontrak    = Kontrak::all();
        
        return view('admin.laporan.laporan_sj_cetak')->with(compact('sj','dari','ke'));
    }

    public function surat_jalan_index1()
    {
        return view('admin.laporan.laporan_sj1');
    }

    public function surat_jalan_cetak1(Request $request)
    {
        $dari   = $request->dari;
        $ke     = $request->ke;
        // $sj     = SuratJalan::where('surat_jalan_status','!=',3)->whereBetween('created_at',[$dari,$ke])->get();
        $sj     = SuratJalan::whereBetween('created_at',[$dari,$ke])->get();
        $kontrak    = Kontrak::all();
        
        return view('admin.laporan.laporan_sj1_cetak')->with(compact('kontrak','sj','dari','ke'));
    }

    public function omset_index()
    {
        return view('admin.laporan.laporan_omset');
    }

    public function omset_cetak(Request $request)
    {
        $dari       = $request->dari;
        $ke         = $request->ke;
        $invoice    = Invoice::whereBetween('created_at',[$dari,$ke])->where('invoice_status',1)->get();
        $kontrak    = Kontrak::orderBy('kontrak_id','asc')->get();
        return view('admin.laporan.laporan_omset_cetak')->with(compact('kontrak','invoice','dari','ke'));
    }

    public function ar_index(){
        return view('admin.laporan.laporan_ar');
    }

    public function ar_cetak(Request $request)
    {
        $dari       = $request->dari;
        $ke         = $request->ke;
        $kontrak    = Kontrak::all();
        $invoice    = Invoice::whereBetween('invoice_tanggal',[$dari,$ke])->get();
        return view('admin.laporan.laporan_ar_cetak')->with(compact('kontrak','invoice','dari','ke'));
    }

    public function ap_index(){
        return view('admin.laporan.laporan_ap');
    }

    public function ap_cetak(Request $request)
    {
        $dari       = $request->dari;
        $ke         = $request->ke;
        $leasing    = Leasing::all();
        $purchasing = Purchasing::all();
        $partner    = Partner::all();
        return view('admin.laporan.laporan_ap_cetak')->with(compact('leasing','purchasing','partner','dari','ke'));
    }

    public function gp_index()
    {
        return view('admin.laporan.laporan_gp');
    }

    public function gp_cetak(Request $request)
    {
        $dari       = $request->dari;
        $ke         = $request->ke;
        $kontrak    = Kontrak::all();
        $invoice    = Invoice::whereBetween('invoice_tanggal',[$dari,$ke])->get();
        return view('admin.laporan.laporan_gp_cetak')->with(compact('kontrak','invoice','dari','ke'));
    }

    public function gpa_index()
    {
        return view('admin.laporan.laporan_gpa');
    }

    public function gpa_cetak(Request $request)
    {
        $dari       = $request->dari;
        $ke         = $request->ke;
        $kendaraan  = Kendaraan::orderBy('kendaraan_nopol','asc')->get();
        $budget     = Budget::all();
        $sj         = SuratJalan::whereBetween('created_at',[$dari,$ke])->get();
        $reconcile  = Reconcile::whereBetween('created_at',[$dari,$ke])->get();
        $purchasing = Purchasing::whereBetween('purchasing_tanggal',[$dari,$ke]);
        return view('admin.laporan.laporan_gpa_cetak')->with(compact('kendaraan','budget','sj','reconcile','purchasing','dari','ke'));
    }
}
