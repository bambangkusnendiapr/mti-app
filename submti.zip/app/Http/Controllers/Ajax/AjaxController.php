<?php

namespace App\Http\Controllers\Ajax;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Master\Kendaraan;
use App\Model\Master\Kota;
use App\Model\Operasional\Budget;
use App\Model\Pemasaran\Kontrak;
use App\Model\Pemasaran\Koreksi;
use App\Model\Pemasaran\Store;
use App\Model\Pemasaran\Tarif;

class AjaxController extends Controller
{
    public function cities($id)
    {
        if($id==0){
            $cities = null;
        }else{
            $cities = Kota::where('province_id',$id)->get();
        }
        return $cities;
    }

    public function nopol($id)
    {
        if($id==0){
            $nopol = null;
        }else{
            $nopol = Kendaraan::where('jenis_kendaraan_id',$id)->get();
        }
        return $nopol;
    }

    public function tarif($id,$store)
    {   
        if($id==0){
            $tarif = null;
        }else{
            $budget = Budget::find($id);
            $tarif = Tarif::where('jenis_kendaraan_id',$budget->jenis_kendaraan_id)->where('store_id',$store)->first();
        }
        return $tarif;
    }

    public function koreksi($id)
    {
        if($id==0){
            $koreksi = null;
        }else{
            $koreksi = Koreksi::find($id);
        }
        return $koreksi;
    }
}
