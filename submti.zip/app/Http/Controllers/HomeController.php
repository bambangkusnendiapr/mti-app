<?php

namespace App\Http\Controllers;

use App\Model\Keuangan\Invoice;
use App\Model\Keuangan\Reconcile;
use App\Model\Master\Kendaraan;
use App\Model\Master\Partner;
use App\Model\Operasional\Budget;
use App\Model\Operasional\SuratJalan;
use App\Model\Other\Leasing;
use App\Model\Other\Purchasing;
use App\Model\Pemasaran\Kontrak;
use Carbon\Carbon;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {   
        $month      = Carbon::now()->format('m');
        $invoice    = Invoice::whereMonth('invoice_tanggal',$month)->get();
        $kontrak    = Kontrak::orderBy('kontrak_id','asc')->get();
        $sj         = SuratJalan::whereMonth('created_at',$month)->get();
        $reconcile  = Reconcile::whereMonth('updated_at',$month)->get();
        $leasing    = Leasing::all();
        $budget     = Budget::all();
        $purchasing = Purchasing::whereMonth('updated_at',$month)->get();
        $partner    = Partner::all();
        $kendaraan  = Kendaraan::orderBy('kendaraan_nopol','asc')->get();
        return view('admin.dashboard')->with(compact('kontrak','invoice','sj','leasing','purchasing','partner','kendaraan','budget','reconcile'));
    }
}
