<?php

namespace App\Model\Akuntansi;

use Illuminate\Database\Eloquent\Model;

class DetailPosting extends Model
{
    //
}
