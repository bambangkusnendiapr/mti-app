<?php

namespace App\Model\Master;

use Illuminate\Database\Eloquent\Model;

class Provinsi extends Model
{
    protected $table    = "indonesia_provinces";
}
