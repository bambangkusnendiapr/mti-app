<?php

namespace App\Model\Master;

use Illuminate\Database\Eloquent\Model;

class Kota extends Model
{
    protected $table    = "indonesia_cities";
}
